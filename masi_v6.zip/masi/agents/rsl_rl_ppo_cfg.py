# # Copyright (c) 2024-2025, Muammer Bay (LycheeAI), Louis Le Lay
# # All rights reserved.
# #
# # SPDX-License-Identifier: BSD-3-Clause
# #
# # Copyright (c) 2022-2025, The Isaac Lab Project Developers.
# # All rights reserved.
# #
# # SPDX-License-Identifier: BSD-3-Clause

# from isaaclab.utils import configclass
# from isaaclab_rl.rsl_rl import (
#     RslRlOnPolicyRunnerCfg,
#     RslRlPpoActorCriticCfg,
#     RslRlPpoAlgorithmCfg,
# )

# @configclass    
# class LiftCubePPORunnerCfg(RslRlOnPolicyRunnerCfg):
#     num_steps_per_env = 24
#     max_iterations = 1500
#     save_interval = 50
#     experiment_name = "masi_logik"
#     empirical_normalization = False
#     policy = RslRlPpoActorCriticCfg(
#         init_noise_std=1.0,
#         actor_hidden_dims=[256, 128, 64],
#         critic_hidden_dims=[256, 128, 64],
#         activation="elu",
#     )
    
#     algorithm = RslRlPpoAlgorithmCfg(
#         value_loss_coef=1.0,
#         use_clipped_value_loss=True,
#         clip_param=0.2,
#         entropy_coef=0.006,
#         num_learning_epochs=5,
#         num_mini_batches=4,
#         learning_rate=1.0e-4,
#         schedule="adaptive",
#         gamma=0.98,
#         lam=0.95,
#         desired_kl=0.01,
#         max_grad_norm=1.0,
#     )
from isaaclab.utils import configclass
from isaaclab_rl.rsl_rl import (
    RslRlOnPolicyRunnerCfg,
    RslRlPpoActorCriticCfg,
    RslRlPpoAlgorithmCfg,
)

@configclass    
class LiftCubePPORunnerCfg(RslRlOnPolicyRunnerCfg):
    num_steps_per_env = 24
    max_iterations = 5000
    save_interval = 50
    experiment_name = "masi_logik"
    # ① 开启经验归一化（obs/rew 归一化由 rsl-rl 维护）
    empirical_normalization = True

    policy = RslRlPpoActorCriticCfg(
        init_noise_std=0.6,          # ② 初始动作噪声小一点，减小早期方差
        actor_hidden_dims=[256, 128, 64],
        critic_hidden_dims=[256, 128, 64],
        activation="elu",
    )

    algorithm = RslRlPpoAlgorithmCfg(
        value_loss_coef=0.5,         # ③ 降低 critic loss 权重，避免过拟合-发散
        use_clipped_value_loss=True,
        clip_param=0.2,
        entropy_coef=0.004,          # ④ 降低熵系数，少冒进
        num_learning_epochs=3,       # ⑤ 训练轮次略降
        num_mini_batches=8,          # ⑥ batch 更小 → 梯度更稳
        learning_rate=5.0e-5,        # ⑦ 降低学习率（配合 ⑤⑥）
        schedule="fixed",            # ⑧ 固定学习率，先追求稳定
        gamma=0.985,                 # ⑨ 略增 gamma，回报更平滑
        lam=0.95,
        desired_kl=0.005,            # ⑩ KL 更严格，防止策略抖得太快
        max_grad_norm=0.5,           # ⑪ 更紧的梯度裁剪
    )

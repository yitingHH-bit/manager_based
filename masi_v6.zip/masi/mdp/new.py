from __future__ import annotations
import math
import torch
from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import subtract_frame_transforms, quat_from_angle_axis, quat_mul, matrix_from_quat

def _yaw_from_quat_wxyz(q: torch.Tensor) -> torch.Tensor:
    w, x, y, z = q.unbind(-1)
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    return torch.atan2(siny_cosp, cosy_cosp)

def _wrap_to_pi(a: torch.Tensor) -> torch.Tensor:
    return (a + math.pi) % (2.0 * math.pi) - math.pi

@torch.no_grad()
def sync_cmd_to_log(
    env: ManagerBasedRLEnv,
    env_ids: torch.Tensor,
    command_name: str,
    robot_asset_cfg: SceneEntityCfg,
    log_asset_cfg: SceneEntityCfg,
    approach_height: float = 0.10,
    descend_xy: float = 0.07,
    final_z_offset: float = 0.0,
    align_start_xy: float = 0.15,
    yaw_offset: float = 0.0,
    upright_base_quat_wxyz: tuple[float, float, float, float] = (1.0, 0.0, 0.0, 0.0),
    tcp_offset_local: tuple[float, float, float] = (0.0, 0.0, 0.0),
):
    device = env.device
    env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    # --- 每个环境一个 stage：0=接近(悬停), 1=下落(锁存，不回跳) ---
    if not hasattr(env, "_cmd_to_log_stage"):
        env._cmd_to_log_stage = torch.zeros(env.num_envs, device=device, dtype=torch.long)
    stage_all = env._cmd_to_log_stage
    stage = stage_all[env_ids]

    robot = env.scene[robot_asset_cfg.name]
    log = env.scene[log_asset_cfg.name]

    # 兼容字段名
    body_pos_w_all  = robot.data.body_pos_w  if hasattr(robot.data, "body_pos_w")  else robot.data.body_link_pos_w
    body_quat_w_all = robot.data.body_quat_w if hasattr(robot.data, "body_quat_w") else robot.data.body_link_quat_w

    # root
    root = robot.data.root_state_w[env_ids]
    root_pos_w = root[:, 0:3]
    root_quat_w = root[:, 3:7]

    # ee
    ee_id = robot_asset_cfg.body_ids[0]
    ee_pos_w = body_pos_w_all[env_ids, ee_id]
    ee_quat_w = body_quat_w_all[env_ids, ee_id]

    # TCP offset in world
    if tcp_offset_local != (0.0, 0.0, 0.0):
        R_ee = matrix_from_quat(ee_quat_w)  # (N,3,3)
        off = torch.tensor(tcp_offset_local, device=device, dtype=ee_pos_w.dtype).view(1,3,1)
        ee_pos_w = ee_pos_w + (R_ee @ off).squeeze(-1)

    # log
    log_state = log.data.root_state_w[env_ids]
    log_pos_w = log_state[:, 0:3]
    log_quat_w = log_state[:, 3:7]

    # 转到 robot root frame
    ee_pos_b, _  = subtract_frame_transforms(root_pos_w, root_quat_w, ee_pos_w, ee_quat_w)
    log_pos_b, _ = subtract_frame_transforms(root_pos_w, root_quat_w, log_pos_w, log_quat_w)

    # 距离判定 + 锁存
    d_xy = torch.linalg.norm((ee_pos_b - log_pos_b)[:, 0:2], dim=-1)
    enter = (stage == 0) & (d_xy < descend_xy)
    if torch.any(enter):
        stage_all[env_ids[enter]] = 1
    stage = stage_all[env_ids]
    descending = stage == 1

    # 目标位置：接近阶段在上方 approach_height；下落阶段到 log中心+final_z_offset
    pos_des_b = log_pos_b.clone()
    z_hover = log_pos_b[:, 2] + float(approach_height)
    z_down  = log_pos_b[:, 2] + float(final_z_offset)
    pos_des_b[:, 2] = torch.where(descending, z_down, z_hover)

    # yaw：用 log 的 yaw（也可以换成bearing，但先这样）
    yaw_w = _yaw_from_quat_wxyz(log_quat_w)
    root_yaw = _yaw_from_quat_wxyz(root_quat_w)
    yaw_b = _wrap_to_pi(yaw_w - root_yaw + float(yaw_offset))

    # 生成 “upright_base_quat * yaw” 的目标姿态（都在 root frame）
    base_q = torch.tensor(upright_base_quat_wxyz, device=device, dtype=root_quat_w.dtype).view(1,4).repeat(env_ids.numel(), 1)
    yaw_q  = quat_from_angle_axis(yaw_b, torch.tensor([0.0, 0.0, 1.0], device=device, dtype=root_quat_w.dtype))
    quat_des_b = quat_mul(yaw_q, base_q)

    # 写回 command buffer
    cmd = env.command_manager.get_command(command_name)
    cmd[env_ids, 0:3] = pos_des_b
    if cmd.shape[1] >= 7:
        cmd[env_ids, 3:7] = quat_des_b

from __future__ import annotations

import math
import torch
# mdp.py 里加上：

from isaaclab.envs import ManagerBasedEnv

from isaaclab.managers import SceneEntityCfg

from isaaclab.utils.math import matrix_from_quat

def reset_log_radial(
    env,
    distance_range: tuple[float, float] = (0.4, 0.6),
    yaw_range: tuple[float, float] = (-math.pi, math.pi),
    z_height: float = 0.03,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("log"),
) -> None:
    """Reset the log object around the robot in a 360-degree ring with random yaw.

    - Samples radius uniformly in [r_min, r_max] and angle uniformly in [-pi, pi].
    - Places the log center at that XY relative to the robot root, with fixed Z height.
    - Sets roll=pitch=0, yaw=random, i.e., the log lies on the ground with Z-up.
    """
    scene = env.scene
    robot = scene["robot"]
    log = scene[asset_cfg.name]

    num_envs = scene.num_envs
    device = robot.device

    # Robot roots in world
    root_w = robot.data.root_state_w[:, :7]

    r_min, r_max = distance_range
    th_min, th_max = yaw_range

    # Sample polar coordinates
    radii = torch.empty((num_envs,), device=device).uniform_(r_min, r_max)
    thetas = torch.empty((num_envs,), device=device).uniform_(th_min, th_max)

    # Positions relative to robot base (in its local XY) then map to world
    # Compute world basis from base orientation
    R_bw = env.scene["robot"].data.root_quat_w
    # Use matrix conversion
    from isaaclab.utils.math import matrix_from_quat

    R_bw_m = matrix_from_quat(root_w[:, 3:7])
    xy_local = torch.stack([torch.cos(thetas) * radii, torch.sin(thetas) * radii, torch.zeros_like(radii)], dim=1)
    xy_world = torch.bmm(R_bw_m, xy_local.unsqueeze(-1)).squeeze(-1)

    # Final world positions
    pos_w = root_w[:, :3] + xy_world
    pos_w[:, 2] = z_height

    # Orientations: Z-up with random yaw around Z
    # quaternion from yaw
    half = thetas * 0.5
    yaw_quat = torch.stack([torch.cos(half), torch.zeros_like(half), torch.zeros_like(half), torch.sin(half)], dim=1)

    # Write root state
    log.write_root_pose_to_sim(pos_w, yaw_quat)

# utils_pose.py (or inside mdp)

def compose_world_pose_from_local(origins, local_pos, local_quat):
    """
    origins: [N,3] env origins in meters
    local_pos: [K,3] positions in *env-local* frame (same env_ids indexing)
    local_quat: [K,4] unit quats (wxyz) in *env-local* frame
    returns world_pos, world_quat (same shapes)
    """
    world_pos = origins + local_pos
    world_quat = local_quat  # no env rotation in Masi grid -> passthrough
    return world_pos, world_quat
# mdp.py  (or wherever your mdp functions live)


@torch.no_grad()
def auto_close_gripper_near_log(
    env,
    dt,  # ★★★ 关键：step 事件需要 (env, dt)
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    log_cfg: SceneEntityCfg   = SceneEntityCfg("log"),
    claw_regex: str = r"revolute_claw_.*",
    ee_body_name: str = "gripper_frame",
    ee_offset_local=(0.0, 0.0, -0.09),   # 与 ActionsCfg.body_offset 对齐
    near_thresh: float = 0.045,          # 4.5cm 以内视为“接近”
    hysteresis: float = 0.01,            # 滞回，防止抖动
    close_cmd: float = 0.0,
    open_cmd: float  = 0.20,
):
    scene = env.scene
    robot = scene[robot_cfg.name]
    log   = scene[log_cfg.name]
    dev   = env.device

    # 爪子关节 ids
    claw_joint_ids, _ = robot.find_joints([claw_regex])

    # 末端位姿（带 offset）
    body_ids, _ = robot.find_bodies([ee_body_name])
    if len(body_ids) == 0:
        return  # 没找到指定刚体就跳过
    b_id = int(body_ids[0])

    ee_p  = robot.data.body_link_pos_w[:, b_id, :]   # (N,3)
    ee_q  = robot.data.body_link_quat_w[:, b_id, :]  # (N,4)
    R     = matrix_from_quat(ee_q)                   # (N,3,3)
    off   = torch.as_tensor(ee_offset_local, device=dev, dtype=ee_p.dtype).view(1,3,1)
    ee_tip= ee_p + (R @ off).squeeze(-1)             # (N,3)

    # log 根位置
    log_p = log.data.root_pos_w[:, :3]               # (N,3)

    # 用 env 原点做本地化，避免巨大 world 坐标引入数值误差
    origins = scene.env_origins
    if not torch.is_tensor(origins):
        origins = torch.as_tensor(origins, device=dev, dtype=ee_p.dtype)

    d = (ee_tip - origins) - (log_p - origins)
    dist = torch.linalg.norm(d, dim=-1)              # (N,)

    # 带滞回的“近/远”状态
    if not hasattr(env, "_auto_grip_state"):
        env._auto_grip_state = torch.zeros_like(dist, dtype=torch.bool, device=dev)
    close_now = (dist < near_thresh) | (env._auto_grip_state & (dist < near_thresh + hysteresis))
    env._auto_grip_state = close_now

    # 下达爪子目标
    tgt = torch.where(close_now, torch.full_like(dist, close_cmd), torch.full_like(dist, open_cmd))
    if len(claw_joint_ids) == 0:
        return
    tgt_expanded = tgt.view(-1, 1).repeat(1, len(claw_joint_ids))  # (N, num_claw)
    robot.set_joint_position_target(tgt_expanded, joint_ids=claw_joint_ids)

# --- ring reset for "log" ----------------------------------------------------

def _yaw_to_quat(yaw: torch.Tensor):
    half = 0.5 * yaw
    return torch.stack([torch.cos(half), torch.zeros_like(yaw), torch.zeros_like(yaw), torch.sin(half)], dim=-1)

def reset_log_pose_on_ring(env, env_ids, *,
                           asset_cfg: SceneEntityCfg,
                           radius=(0.14, 0.22),
                           theta=(-math.pi, math.pi),
                           z=0.03,
                           yaw_mode: str = "tangent"):
    device = env.device
    env_ids = torch.as_tensor(env_ids if env_ids is not None else torch.arange(env.scene.num_envs, device=device),
                              device=device, dtype=torch.long)
    n = env_ids.numel()
    if n == 0: return
    r  = torch.empty(n, device=device).uniform_(*radius)
    th = torch.empty(n, device=device).uniform_(*theta)

    # 局部环形坐标
    pos_local = torch.stack([r*torch.cos(th), r*torch.sin(th), torch.full((n,), z, device=device)], dim=-1)

    # 加每个 env 的平铺偏移（不要堆在 (0,0)）
    if hasattr(env.scene, "env_origins"):
        pos = pos_local.clone()
        pos[:, 0:2] += env.scene.env_origins[env_ids, 0:2]
    else:
        pos = pos_local

    # 朝向：切向/径向/固定
    if yaw_mode == "tangent":
        yaw = th + math.pi*0.5
    elif yaw_mode == "radial":
        yaw = th
    else:
        yaw = torch.zeros_like(th)
    rot = _yaw_to_quat(yaw)

    entity = env.scene[asset_cfg.name]
    root_state = (entity.data.root_state_w.clone()
                  if hasattr(entity.data, "root_state_w")
                  else entity.data.default_root_state.clone())
    root_state[env_ids, 0:3] = pos
    root_state[env_ids, 3:7] = rot
    root_state[env_ids, 7:13] = 0.0

    # 写回（兼容两种写法）
    if hasattr(entity, "set_root_state"):
        try: entity.set_root_state(root_state)
        except TypeError: pass
    if hasattr(entity, "write_root_state_to_sim"):
        try: entity.write_root_state_to_sim(root_state)
        except TypeError:
            if hasattr(entity.data, "root_state_w"):
                entity.data.root_state_w[:] = root_state
            entity.write_root_state_to_sim()

def log_dir_in_base(env, *, robot_name="robot", log_name="log"):
    rob = env.scene[robot_name]
    lg  = env.scene[log_name]

    # —— 安全拿 root_state（不同版本字段名不同）——
    rsr = getattr(rob.data, "root_state_w", None)
    if rsr is None:
        rsr = rob.data.root_state                #

    rsl = getattr(lg.data, "root_state_w", None)
    if rsl is None:
        rsl = lg.data.root_state

    # 位置（世界系）
    base_xy = rsr[:, 0:2]
    log_xy  = rsl[:, 0:2]
    v = log_xy - base_xy
    dist = torch.linalg.norm(v, dim=1).clamp_min(1e-6)  # 避免除零

    # 从四元数(w,x,y,z)取底座yaw
    qw, qx, qy, qz = rsr[:, 3], rsr[:, 4], rsr[:, 5], rsr[:, 6]
    yaw_base = torch.atan2(2*(qw*qz + qx*qy), 1 - 2*(qy*qy + qz*qz))

    # 目标世界系方位角 & 与底座yaw差
    dir_world = torch.atan2(v[:, 1], v[:, 0])
    yaw_rel = (dir_world - yaw_base + math.pi) % (2*math.pi) - math.pi  # (-pi, pi]

    # 归一化方向 + 距离 + 相对yaw（4维）
    dxn = v[:, 0] / dist
    dyn = v[:, 1] / dist
    return torch.stack([dxn, dyn, dist, yaw_rel], dim=1)


# def auto_grasp_log_fsm(
#     env: ManagerBasedRLEnv,
#     env_ids: torch.Tensor,
#     robot_asset_cfg: SceneEntityCfg,
#     log_asset_cfg: SceneEntityCfg,
#     close_dist: float,
#     lift_height: float,
#     open_action: float,
#     close_action: float,
# ) -> None:
#     """
#     规则 + RL 的自动抓取逻辑（作为 EventTerm 使用）。

#     状态机定义（每个 env 一条）:
#         0: OPEN     - 爪子张开
#         1: CLOSING  - 末端接近木头后开始闭合
#         2: GRASPED  - 木头被抬起后一直保持闭合

#     逻辑：
#       - 每个 step 调用一次（EventCfg 里 mode=\"interval\"）
#       - 根据 ee 和 log 的相对位置，更新内部 FSM 状态
#       - 再根据状态，**覆盖 gripper_action 那一段的 action 值**
#     """
#     device = env.device

#     # env_ids 统一成 LongTensor
#     if isinstance(env_ids, slice):
#         env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
#     else:
#         env_ids = env_ids.to(device=device, dtype=torch.long)

#     if env_ids.numel() == 0:
#         return

#     # 取场景里的 robot 和 log 句柄
#     robot = env.scene[robot_asset_cfg.name]
#     log = env.scene[log_asset_cfg.name]

#     # -------------------------------
#     # 1) 初始化 FSM 缓冲（第一次调用时）
#     # -------------------------------
#     if not hasattr(env, "_auto_grasp_state"):
#         # 每个 env 一个状态：0=open, 1=closing, 2=grasped
#         env._auto_grasp_state = torch.zeros(
#             env.num_envs, dtype=torch.int64, device=device
#         )
#         # 记录每个 env 中木头的“初始高度”，之后用来判断是否被抬起
#         env._log_init_height = log.data.root_state_w[:, 2].clone()

#     state_all: torch.Tensor = env._auto_grasp_state        # [num_envs]
#     log_init_h_all: torch.Tensor = env._log_init_height    # [num_envs]

#     state = state_all[env_ids]
#     log_init_h = log_init_h_all[env_ids]

#     # -------------------------------
#     # 2) 在 reset 时重置 FSM
#     # -------------------------------
#     # Isaac Lab 一般有 reset_buf，=1 表示该 env 需要 reset / 刚 reset
#     if hasattr(env, "reset_buf"):
#         reset_mask = env.reset_buf[env_ids] > 0
#         if reset_mask.any():
#             env_ids_reset = env_ids[reset_mask]
#             # 重置状态为 OPEN
#             state_all[env_ids_reset] = 0
#             # 重新记录木头初始高度
#             log_init_h_all[env_ids_reset] = log.data.root_state_w[env_ids_reset, 2]
#             # 更新本地 view
#             state = state_all[env_ids]
#             log_init_h = log_init_h_all[env_ids]

#     # -------------------------------
#     # 3) 计算 EE 与 log 的相对位置
#     # -------------------------------
#     # 末端 link id（我们在 EventCfg 里已写 body_names=["gripper_frame"]）
#     ee_body_ids = robot_asset_cfg.body_ids
#     # body_state_w: [num_envs, num_bodies, 13]
#     ee_state = robot.data.body_state_w[env_ids, ee_body_ids, :]  # [N, 1, 13] 或 [N, 13]
#     if ee_state.ndim == 3:
#         ee_state = ee_state[:, 0, :]  # 只要那一个 body

#     ee_pos = ee_state[:, 0:3]            # [N, 3]

#     # log 的 root_state_w: [num_envs, 13]
#     log_state = log.data.root_state_w[env_ids]   # [N, 13]
#     log_pos = log_state[:, 0:3]                  # [N, 3]

#     # 距离 & 高度
#     dist = torch.linalg.norm(ee_pos - log_pos, dim=-1)  # [N]
#     log_h = log_pos[:, 2]                               # [N]

#     # -------------------------------
#     # 4) FSM 状态转移
#     # -------------------------------
#     is_open = state == 0
#     is_closing = state == 1
#     is_grasped = state == 2

#     # 1) 在 OPEN 状态，如果 EE 靠近 log（小于 close_dist），切到 CLOSING
#     to_closing = is_open & (dist < close_dist)

#     # 2) 在 CLOSING 状态，如果木头被抬起了一定高度，切到 GRASPED
#     to_grasped = is_closing & (log_h > (log_init_h + lift_height))

#     new_state = state.clone()
#     new_state[to_closing] = 1
#     new_state[to_grasped] = 2

#     # 写回全局
#     state_all[env_ids] = new_state

#     # -------------------------------
#     # 5) 找到 gripper_action 在整体 action 向量中的 slice
#     # -------------------------------
#     if not hasattr(env, "_gripper_action_slice"):
#         am = env.action_manager
#         start = 0
#         grip_slice = None
#         for name, dim in zip(am.active_terms, am.action_term_dim):
#             if name == "gripper_action":
#                 grip_slice = slice(start, start + dim)
#                 break
#             start += dim

#         if grip_slice is None:
#             # 没有找到 gripper_action term，就直接退出
#             return

#         env._gripper_action_slice = grip_slice

#     grip_slice = env._gripper_action_slice

#     # ActionManager._action: [num_envs, total_action_dim]
#     # 这里我们直接覆盖掉 gripper_action 对应维度的动作值
#     actions_buf = env.action_manager._action

#     open_mask = new_state == 0
#     closing_mask = new_state == 1
#     grasped_mask = new_state == 2

#     # OPEN 状态：强制张开
#     if open_mask.any():
#         actions_buf[env_ids[open_mask], grip_slice] = open_action

#     # CLOSING / GRASPED 状态：强制闭合
#     closing_or_grasped = closing_mask | grasped_mask
#     if closing_or_grasped.any():
#         actions_buf[env_ids[closing_or_grasped], grip_slice] = close_action
# V 11
# def auto_grasp_log_fsm(
#     env,
#     env_ids,
#     robot_asset_cfg: SceneEntityCfg,
#     log_asset_cfg: SceneEntityCfg,
#     close_dist: float = 0.02,
#     keep_open_xy: float = 0.10,
#     keep_open_z_above: float = 0.02,
#     lift_height: float = 0.15,
#     open_action: float = 1.0,
#     close_action: float = -1.0,
# ):
#     """
#     靠近过程中永远OPEN：
#       - XY 还没对齐到 keep_open_xy 内 -> OPEN
#       - 或 EE 还明显在 log 上方 keep_open_z_above -> OPEN
#     只有真正到位(距离<close_dist)才 CLOSE；抬起后保持 CLOSE
#     """
#     device = env.device

#     # env_ids 兼容 slice/tensor
#     if isinstance(env_ids, slice):
#         env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
#     else:
#         env_ids = env_ids.to(device=device, dtype=torch.long)
#     if env_ids.numel() == 0:
#         return

#     robot = env.scene[robot_asset_cfg.name]
#     log = env.scene[log_asset_cfg.name]

#     ee_body = (robot_asset_cfg.body_names[0] if getattr(robot_asset_cfg, "body_names", None) else "gripper_frame")
#     body_ids, _ = robot.find_bodies([ee_body])
#     ee_idx = int(body_ids[0])

#     ee_pos_w  = robot.data.body_state_w[env_ids, ee_idx, 0:3]     # (M,3)
#     log_pos_w = log.data.root_state_w[env_ids, 0:3]               # (M,3)

#     d = ee_pos_w - log_pos_w
#     d_xy = torch.linalg.norm(d[:, 0:2], dim=1)
#     dist = torch.linalg.norm(d, dim=1)

#     # 还在靠近 -> 强制张开
#     approaching = (d_xy > keep_open_xy) | (d[:, 2] > keep_open_z_above)

#     # 到位才闭合
#     ready_to_close = (~approaching) & (dist < close_dist)

#     # 抬起后保持闭合（用 log 高度判定）
#     lifted = (log_pos_w[:, 2] > lift_height)

#     # 输出每个 env 一个动作值
#     grip = torch.full((env_ids.numel(),), float(open_action), device=device)
#     grip[ready_to_close | lifted] = float(close_action)

#     # ✅ 如果你的旧实现是“返回动作让系统覆盖”，就返回
#     return grip

import torch
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import matrix_from_quat

#  V14  
# @torch.no_grad()
# def auto_grasp_log_fsm(
#     env,
#     env_ids,
#     robot_asset_cfg: SceneEntityCfg,
#     log_asset_cfg: SceneEntityCfg,
#     close_dist: float = 0.05,
#     keep_open_xy: float = 0.06,
#     keep_open_z_above: float = 0.01,
#     lift_height: float = 0.15,
#     open_action: float = 1.0,
#     close_action: float = -1.0,
#     hold_steps: int = 8,

#     # ✅ 新增：抬起控制（覆盖 arm_action）
#     lift_action: float = 1.0,      # 对应 dz 的动作值（乘你的 scale=0.01）
#     hold_arm_zero: bool = True,    # close 时把 arm action 置 0，避免继续推
# ):
#     device = env.device
#     if isinstance(env_ids, slice):
#         env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
#     else:
#         env_ids = env_ids.to(device=device, dtype=torch.long)
#     if env_ids.numel() == 0:
#         return

#     robot = env.scene[robot_asset_cfg.name]
#     log   = env.scene[log_asset_cfg.name]

#     # ---------------------------
#     # init buffers
#     # ---------------------------
#     if not hasattr(env, "_grasp_phase"):
#         env._grasp_phase = torch.zeros(env.num_envs, dtype=torch.long, device=device)    # 0/1/2
#         env._hold_counter = torch.zeros(env.num_envs, dtype=torch.long, device=device)
#         env._log_z0 = log.data.root_state_w[:, 2].clone()

#     # reset handling
#     if hasattr(env, "reset_buf"):
#         r = env.reset_buf > 0
#         if r.any():
#             env._grasp_phase[r] = 0
#             env._hold_counter[r] = 0
#             env._log_z0[r] = log.data.root_state_w[r, 2]

#     # EE pos (用 gripper_frame 或你传进来的 body_names[0])
#     ee_body = (robot_asset_cfg.body_names[0] if getattr(robot_asset_cfg, "body_names", None) else "gripper_frame")
#     body_ids, _ = robot.find_bodies([ee_body])
#     if len(body_ids) == 0:
#         return
#     ee_idx = int(body_ids[0])

#     ee_pos_w  = robot.data.body_state_w[env_ids, ee_idx, 0:3]
#     log_pos_w = log.data.root_state_w[env_ids, 0:3]

#     d = ee_pos_w - log_pos_w
#     d_xy = torch.linalg.norm(d[:, 0:2], dim=1)
#     dist = torch.linalg.norm(d, dim=1)

#     phase = env._grasp_phase[env_ids]

#     approaching = (d_xy > keep_open_xy) | (d[:, 2] > keep_open_z_above)
#     ready_to_close = (~approaching) & (dist < close_dist)

#     # phase0 -> phase1
#     to_p1 = (phase == 0) & ready_to_close
#     if to_p1.any():
#         ids = env_ids[to_p1]
#         env._grasp_phase[ids] = 1
#         env._hold_counter[ids] = 0

#     # phase1 hold -> phase2
#     phase = env._grasp_phase[env_ids]
#     p1 = (phase == 1)
#     if p1.any():
#         ids = env_ids[p1]
#         env._hold_counter[ids] += 1
#         to_p2 = env._hold_counter[ids] >= int(hold_steps)
#         if to_p2.any():
#             env._grasp_phase[ids[to_p2]] = 2

#     # lifted detection (保险)
#     phase = env._grasp_phase[env_ids]
#     lifted = (log_pos_w[:, 2] > (env._log_z0[env_ids] + lift_height))
#     if lifted.any():
#         env._grasp_phase[env_ids[lifted]] = 2

#     # ---------------------------
#     # 1) override gripper_action
#     # ---------------------------
#     phase = env._grasp_phase[env_ids]
#     grip = torch.full((env_ids.numel(),), float(open_action), device=device)
#     grip[phase >= 1] = float(close_action)

#     if not hasattr(env, "_gripper_action_slice"):
#         am = env.action_manager
#         start = 0
#         s = None
#         for name, dim in zip(am.active_terms, am.action_term_dim):
#             if name == "gripper_action":
#                 s = slice(start, start + dim)
#                 break
#             start += dim
#         if s is None:
#             raise RuntimeError("Cannot find 'gripper_action' in action_manager.")
#         env._gripper_action_slice = s

#     env.action_manager._action[env_ids, env._gripper_action_slice] = grip.unsqueeze(-1)  # (N,1)

#     # ---------------------------
#     # 2) ✅ override arm_action (关键：让爪子真的抬起来)
#     # ---------------------------
#     if not hasattr(env, "_arm_action_slice"):
#         am = env.action_manager
#         start = 0
#         s = None
#         for name, dim in zip(am.active_terms, am.action_term_dim):
#             if name == "arm_action":
#                 s = slice(start, start + dim)
#                 break
#             start += dim
#         if s is None:
#             raise RuntimeError("Cannot find 'arm_action' in action_manager.")
#         env._arm_action_slice = s

#     arm_slice = env._arm_action_slice

#     # arm_action 期望是 (dx,dy,dz) —— 你用的是 command_type="position"
#     arm = torch.zeros((env_ids.numel(), 3), device=device)

#     # phase>=1：避免继续推（可选）
#     if hold_arm_zero:
#         arm[phase >= 1, :] = 0.0

#     # phase==2：强制 dz 向上
#     arm[phase == 2, 2] = float(lift_action)

#     env.action_manager._action[env_ids, arm_slice] = arm

#V 21   

import torch
from isaaclab.utils.math import quat_apply


@torch.no_grad()
def auto_grasp_log_fsm(
    env,
    env_ids: torch.Tensor,
    robot_asset_cfg,
    log_asset_cfg,
    # ---- geometry thresholds (match Direct env intuition) ----
    close_dist: float = 0.05,          # Euclidean distance threshold (tip->log center) to start closing
    open_dist: float = 0.08,           # if farther than this, force open
    # ---- anti "hover close" gate (tip vs log top) ----
    keep_open_z_above: float = 0.04,   # not mandatory; used for default close_z_above
    tcp_offset_local=(0.0, 0.0, 0.0),  # gripper_frame -> tip offset in local EE frame
    tool_joint_names=("revolute_claw_1", "revolute_claw_2"),
    open_margin_ratio: float = 0.001,  # keep away from hard limits
    grasp_hold_steps: int = 6,         # require N consecutive steps near to commit to close
    lift_steps: int = 60,              # lift for N steps
    lift_after_close: bool = True,
    lift_height: float = 0.12,         # total lift height (base-z) to add to command over lift_steps
    min_lift_success: float = 0.02,
    # NOTE: By default we do NOT reopen automatically after a close.
    # This avoids the common failure mode: "it closed once, then opened again" due to
    # distance / log motion / small contact dynamics.
    fail_reopen_if_not_lifted: bool = False,
    # If your policy does not reliably produce upward motion after phase==2,
    # enable this to inject an upward dz directly into the arm action buffer.
    # This makes "phase=2" visibly lift even when the RL action is noisy.
    force_lift_via_actions: bool = True,
    lift_action: float = 0.25,
    hold_xy_during_lift: bool = True,
    command_name: str = "ee_pose",
    debug_print: bool = False,
    dbg_interval_s: float = 0.5,
    close_z_above: float | None = None,
    close_z_below: float | None = None,
):
    """Rule-based gripper FSM.
    - Uses EE body (robot_asset_cfg.body_names[0]) as reference frame.
    - Computes a "tip" point by applying tcp_offset_local in EE frame.
    - Drives claw joints directly via set_joint_position_target (no action_manager dependency).
    - Optionally lifts by raising command z during phase 2.
    """
    device = env.device
    base_env = env.unwrapped if hasattr(env, "unwrapped") else env

    # env_ids can be slice
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    robot = env.scene[robot_asset_cfg.name]
    log = env.scene[log_asset_cfg.name]

    # ---------------------------
    # Init buffers (once)
    # ---------------------------
    if not hasattr(base_env, "_grasp_phase"):
        base_env._grasp_phase = torch.zeros(env.num_envs, dtype=torch.long, device=device)  # 0=open, 1=closing, 2=lift/hold
        base_env._close_counter = torch.zeros(env.num_envs, dtype=torch.long, device=device)
        base_env._lift_counter = torch.zeros(env.num_envs, dtype=torch.long, device=device)
        base_env._log_init_z = torch.zeros(env.num_envs, dtype=torch.float32, device=device)
        # lock values in base-translation frame (used by sync fn)
        base_env._lock_xy = torch.zeros(env.num_envs, 2, dtype=torch.float32, device=device)
        base_env._lock_z0 = torch.zeros(env.num_envs, dtype=torch.float32, device=device)
        base_env._dbg_timer = torch.zeros(env.num_envs, dtype=torch.float32, device=device)
        base_env._ee_body_cache = {}

    # ---------------------------
    # Reset detection
    # ---------------------------
    reset_mask = torch.zeros(env_ids.numel(), dtype=torch.bool, device=device)
    if hasattr(base_env, "reset_buf"):
        reset_mask |= base_env.reset_buf[env_ids]
    if hasattr(base_env, "episode_length_buf"):
        reset_mask |= (base_env.episode_length_buf[env_ids] == 0)

    if reset_mask.any():
        rid = env_ids[reset_mask]
        base_env._grasp_phase[rid] = 0
        base_env._close_counter[rid] = 0
        base_env._lift_counter[rid] = 0
        base_env._log_init_z[rid] = log.data.root_pos_w[rid, 2]

    # ---------------------------
    # EE body id resolve
    # ---------------------------
    ee_body_name = (
        robot_asset_cfg.body_names[0]
        if hasattr(robot_asset_cfg, "body_names") and len(robot_asset_cfg.body_names) > 0
        else "ee"
    )
    if ee_body_name not in base_env._ee_body_cache:
        base_env._ee_body_cache[ee_body_name] = int(robot.find_bodies(ee_body_name)[0][0])
    ee_body_id = base_env._ee_body_cache[ee_body_name]

    # EE pose (world)
    ee_pos_w = robot.data.body_state_w[env_ids, ee_body_id, 0:3]
    ee_quat_w = robot.data.body_state_w[env_ids, ee_body_id, 3:7]

    # tip pose (world)
    tip_off = torch.tensor(tcp_offset_local, device=device, dtype=torch.float32).reshape(1, 3)
    ee_tip_w = ee_pos_w + quat_apply(ee_quat_w, tip_off.repeat(env_ids.numel(), 1))

    # log pose (world)
    log_pos_w = log.data.root_pos_w[env_ids, 0:3]

    # log top reference (for dz gating)
    try:
        log_h = float(getattr(getattr(log, "cfg", None).spawn, "size")[2])
    except Exception:
        log_h = 0.04
    log_top_w = log_pos_w.clone()
    log_top_w[:, 2] += 0.5 * log_h

    # distances
    d = torch.linalg.norm(ee_tip_w - log_pos_w, dim=1)  # tip->log center
    d_xy = torch.linalg.norm(ee_tip_w[:, 0:2] - log_pos_w[:, 0:2], dim=1)
    dz_top = ee_tip_w[:, 2] - log_top_w[:, 2]  # >0 means tip ABOVE log top

    # close window defaults (prevent hovering close)
    if close_z_above is None:
        close_z_above = float(min(0.02, max(keep_open_z_above, 0.005)))  # default ~2cm
    if close_z_below is None:
        close_z_below = 0.03

    # open/close conditions
    want_open = d > float(open_dist)
    want_close = (d < float(close_dist)) & (dz_top <= float(close_z_above)) & (dz_top >= -float(close_z_below))

    # ---------------------------
    # FSM transitions
    # ---------------------------
    phase = base_env._grasp_phase[env_ids]

    # phase0: force open, wait want_close for N steps
    mask0 = phase == 0
    if mask0.any():
        ids0 = env_ids[mask0]
        wc0 = want_close[mask0]
        base_env._close_counter[ids0] = torch.where(
            wc0,
            base_env._close_counter[ids0] + 1,
            torch.zeros_like(base_env._close_counter[ids0]),
        )

        enter = wc0 & (base_env._close_counter[ids0] >= int(grasp_hold_steps))
        if enter.any():
            ids_enter = ids0[enter]
            base_env._grasp_phase[ids_enter] = 1
            base_env._close_counter[ids_enter] = 0

            # lock tip target in BASE-translation frame
            base_pos_w = robot.data.root_state_w[ids_enter, 0:3]
            # use CURRENT tip position lock
            tip_enter_w = ee_tip_w[mask0][enter]
            base_env._lock_xy[ids_enter] = tip_enter_w[:, 0:2] - base_pos_w[:, 0:2]
            base_env._lock_z0[ids_enter] = tip_enter_w[:, 2] - base_pos_w[:, 2]

    # phase1: closing -> go lift/hold
    phase = base_env._grasp_phase[env_ids]
    mask1 = phase == 1
    if mask1.any():
        # IMPORTANT: once we commit to "closing" we do NOT reopen based on distance.
        # This prevents the "closed once then suddenly opened" issue.
        ids1 = env_ids[mask1]
        base_env._grasp_phase[ids1] = 2
        base_env._lift_counter[ids1] = 0

    # phase2: hold closed; optionally lift command z (only meaningful if your action uses command_name)
    phase = base_env._grasp_phase[env_ids]
    mask2 = phase == 2
    if mask2.any() and lift_after_close:
        ids2 = env_ids[mask2]

        # lift command: add dz each step until lift_steps
        still = base_env._lift_counter[ids2] < int(lift_steps)
        if still.any():
            ids_lift = ids2[still]
            cmd = env.command_manager.get_command(command_name)  # base-frame command (x,y,z,quat)
            dz = float(lift_height) / max(int(lift_steps), 1)
            cmd[ids_lift, 2] += dz

        base_env._lift_counter[ids2] += 1

        if fail_reopen_if_not_lifted:
            done = base_env._lift_counter[ids2] >= int(lift_steps)
            if done.any():
                ids_done = ids2[done]
                lifted = (log.data.root_pos_w[ids_done, 2] - base_env._log_init_z[ids_done]) >= float(min_lift_success)
                fail = ~lifted
                if fail.any():
                    ids_fail = ids_done[fail]
                    base_env._grasp_phase[ids_fail] = 0
                    base_env._close_counter[ids_fail] = 0
                    base_env._lift_counter[ids_fail] = 0

    # ---------------------------
    # Drive tool joints directly
    # ---------------------------
    # Resolve joint ids robustly
    tjn = tuple(tool_joint_names)
    tool_joint_ids, _ = robot.find_joints(list(tjn))
    # IsaacLab APIs sometimes return (tensor, names) or (list, names)
    if isinstance(tool_joint_ids, (list, tuple)):
        if len(tool_joint_ids) == 0:
            tool_joint_ids = torch.empty((0,), device=device, dtype=torch.long)
        else:
            # if first element is tensor (some APIs wrap)
            if isinstance(tool_joint_ids[0], torch.Tensor):
                tool_joint_ids = tool_joint_ids[0]
            else:
                tool_joint_ids = torch.tensor(tool_joint_ids, device=device, dtype=torch.long)
    elif not isinstance(tool_joint_ids, torch.Tensor):
        tool_joint_ids = torch.tensor([int(tool_joint_ids)], device=device, dtype=torch.long)

    tool_joint_ids = tool_joint_ids.to(device=device, dtype=torch.long).reshape(-1)
    if tool_joint_ids.numel() == 0:
        return

    # joint limits (prefer new API)
    lim_all = getattr(robot.data, "joint_pos_limits", None)
    if lim_all is None:
        lim_all = robot.data.joint_limits  # fallback for older versions

    eid0 = int(env_ids[0].item())
    lim = lim_all[eid0, tool_joint_ids]  # (J,2) or (2,)
    if lim.ndim == 1:
        lim = lim.unsqueeze(0)
    low = lim[:, 0]
    high = lim[:, 1]

    # open = low, close = high for claw joints
    open_tgt = low.clone()
    close_tgt = high.clone()

    # soften by margin
    r = float(open_margin_ratio)
    open_tgt = open_tgt * (1.0 - r) + close_tgt * r
    close_tgt = close_tgt * (1.0 - r) + open_tgt * r

    # desired open/close per env
    # Once phase>=1 (closing or lifting), we KEEP CLOSED no matter what distance becomes.
    # The only thing that re-opens is a reset or an explicit failure transition.
    desired_open = (base_env._grasp_phase[env_ids] == 0)
    tgt = torch.where(
        desired_open.unsqueeze(1),
        open_tgt.unsqueeze(0).expand(env_ids.numel(), -1),
        close_tgt.unsqueeze(0).expand(env_ids.numel(), -1),
    )

    # If only 1 joint id was resolved, slice tgt to match
    if tgt.shape[1] != tool_joint_ids.numel():
        tgt = tgt[:, : tool_joint_ids.numel()]

    robot.set_joint_position_target(tgt, joint_ids=tool_joint_ids, env_ids=env_ids)
    robot.write_data_to_sim()

    # ---------------------------
    # Optional: force a visible lift by overriding the arm action buffer.
    # This is needed if your ManagerBased action term does NOT track `command_name`
    # (common when using relative IK actions).
    #
    # We keep it very conservative:
    #   - Only active in phase==2
    #   - Only while lift_counter < lift_steps
    #   - Only writes dz (and optionally zeros dx,dy)
    #
    if force_lift_via_actions and hasattr(env, "action_manager"):
        am = env.action_manager
        act = getattr(am, "_action", None)
        if isinstance(act, torch.Tensor) and act.ndim == 2 and act.shape[0] == env.num_envs:
            # find arm action slice once (fallback: first 3 dims)
            if not hasattr(base_env, "_arm_action_slice"):
                arm_slice = None
                try:
                    # common layouts: list of term specs / dict of terms
                    specs = getattr(am, "action_term_specs", None)
                    if specs is None:
                        specs = getattr(am, "_action_term_specs", None)
                    if specs is not None:
                        start = 0
                        for spec in specs:
                            name = getattr(spec, "name", None) or getattr(spec, "term_name", None)
                            dim = getattr(spec, "dim", None) or getattr(spec, "action_dim", None)
                            if dim is None:
                                # last resort: try len on range
                                dim = int(getattr(spec, "num_actions", 0))
                            dim = int(dim)
                            if name == "arm_action":
                                arm_slice = slice(start, start + dim)
                                break
                            start += dim
                except Exception:
                    arm_slice = None

                # fallback: assume first 3 dims correspond to arm action
                if arm_slice is None:
                    arm_slice = slice(0, min(3, act.shape[1]))
                base_env._arm_action_slice = arm_slice

            arm_slice = base_env._arm_action_slice

            # apply lift on phase==2 while lifting
            phase_all = base_env._grasp_phase
            ids2 = env_ids[phase_all[env_ids] == 2]
            if ids2.numel() > 0:
                still = base_env._lift_counter[ids2] < int(lift_steps)
                ids_lift = ids2[still]
                if ids_lift.numel() > 0 and arm_slice.stop - arm_slice.start >= 3:
                    if hold_xy_during_lift:
                        act[ids_lift, arm_slice.start : arm_slice.start + 2] = 0.0
                    act[ids_lift, arm_slice.start + 2] = float(lift_action)

    # ---------------------------
    # Debug prints (one line)
    # ---------------------------
    if debug_print:
        step_dt = float(getattr(base_env, "step_dt", 1.0 / 60.0))
        base_env._dbg_timer[env_ids] += step_dt
        do_print = base_env._dbg_timer[env_ids] >= float(dbg_interval_s)
        if do_print.any():
            ids_dbg = env_ids[do_print]
            idx = torch.nonzero(do_print).squeeze(-1)
            base_env._dbg_timer[ids_dbg] = 0.0
            i0 = int(idx[0].item())
            eid = int(env_ids[i0].item())
            print(
                f"[DBG] phase={int(base_env._grasp_phase[eid].item())} "
                f"d={float(d[i0]):.4f} d_xy={float(d_xy[i0]):.4f} dz_top={float(dz_top[i0]):.4f} "
                f"want_close={bool(want_close[i0].item())} want_open={bool(want_open[i0].item())} "
                f"c_cnt={int(base_env._close_counter[eid].item())} l_cnt={int(base_env._lift_counter[eid].item())}"
            )
            print("#" * 80)

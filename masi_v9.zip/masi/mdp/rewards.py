from __future__ import annotations

import math
import torch

from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import matrix_from_quat

# =============================================================================
# ✅ 统一 TCP 偏移：gripper_frame -> 爪子中心 9cm
# 方向先按你之前用的 -Z；如果方向不对，改成 (+0.09,0,0) 或 (0,+0.09,0)
# =============================================================================
DEFAULT_EE_OFFSET_LOCAL = (0.0, 0.0, -0.09)


# -----------------------------------------------------------------------------
# 共用小工具：数值护栏
# -----------------------------------------------------------------------------
def _safe(x: torch.Tensor, name: str = "") -> torch.Tensor:
    x = torch.nan_to_num(x, nan=0.0, posinf=1e6, neginf=-1e6)
    return torch.clamp(x, -1e3, 1e3)


def _safe_div(num: torch.Tensor, den: torch.Tensor) -> torch.Tensor:
    return num / (den + 1e-8)


def _get_env_origins(env) -> torch.Tensor:
    origins = env.scene.env_origins
    return origins if isinstance(origins, torch.Tensor) else torch.as_tensor(origins, device=env.device)


# -----------------------------------------------------------------------------
# 兼容：获取 body index（带缓存，避免每 step find_bodies）
# -----------------------------------------------------------------------------
def _get_body_index_cached(env, robot, body_name: str) -> int:
    cache = getattr(env, "_body_name_to_id_cache", None)
    if cache is None:
        cache = {}
        env._body_name_to_id_cache = cache

    key = (id(robot), body_name)
    if key in cache:
        return cache[key]

    body_ids, _ = robot.find_bodies([body_name])
    idx = int(body_ids[0])
    cache[key] = idx
    return idx


# -----------------------------------------------------------------------------
# 兼容：获取 body 位姿（优先 body_state_w）
# -----------------------------------------------------------------------------
def _get_body_pose_w(robot, body_id: int) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Returns:
      pos_w:  (N,3)
      quat_w: (N,4)  (w, x, y, z) in IsaacLab convention
    """
    data = robot.data

    if hasattr(data, "body_state_w"):
        pos_w = data.body_state_w[:, body_id, :3]
        quat_w = data.body_state_w[:, body_id, 3:7]
        return pos_w, quat_w

    if hasattr(data, "body_pos_w") and hasattr(data, "body_quat_w"):
        pos_w = data.body_pos_w[:, body_id, :]
        quat_w = data.body_quat_w[:, body_id, :]
        return pos_w, quat_w

    # 你原来用的字段：有些版本可能不存在；这里作为最后兜底
    if hasattr(data, "body_link_pos_w") and hasattr(data, "body_link_quat_w"):
        pos_w = data.body_link_pos_w[:, body_id, :]
        quat_w = data.body_link_quat_w[:, body_id, :]
        return pos_w, quat_w

    raise AttributeError("robot.data 找不到 body_state_w / body_pos_w / body_link_pos_w 等字段")


# -----------------------------------------------------------------------------
# 奖励：EE(TCP) 到 log 的距离（可做 shaping）
# -----------------------------------------------------------------------------
def ee_to_log_distance(
    env,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    log_cfg: SceneEntityCfg = SceneEntityCfg("log"),
    ee_body_name: str = "gripper_frame",
    ee_offset_local: tuple[float, float, float] = DEFAULT_EE_OFFSET_LOCAL,
    use_l2: bool = True,
    shaped: bool = True,
    scale: float = 0.25,
) -> torch.Tensor:
    """有界奖励（0~1，越近越接近 1）或负距离（越近越大）。"""
    device = env.device
    origins = _get_env_origins(env)  # (N,3)

    robot = env.scene[robot_cfg.name]
    log = env.scene[log_cfg.name]

    # body id
    ee_idx = _get_body_index_cached(env, robot, ee_body_name)

    # body pose
    ee_pos_w, ee_quat_w = _get_body_pose_w(robot, ee_idx)

    # TCP: ee_pos_w + R(ee)*offset_local
    R_ee = matrix_from_quat(ee_quat_w)  # (N,3,3)
    ee_off = torch.as_tensor(ee_offset_local, device=device, dtype=ee_pos_w.dtype).view(1, 3, 1)
    ee_pos_w = ee_pos_w + (R_ee @ ee_off).squeeze(-1)  # (N,3)

    # log root pos
    log_root = getattr(log.data, "root_pos_w", None)
    if log_root is None:
        # 兜底：某些对象只有 root_state_w
        log_root = log.data.root_state_w[:, 0:3]

    if log_root.ndim == 2:
        log_pos_w = log_root
    elif log_root.ndim == 3:
        log_pos_w = log_root[:, 0, :]
    else:
        log_pos_w = log_root.reshape(log_root.shape[0], -1)[..., :3]

    # to env local
    ee_pos_local = ee_pos_w - origins
    log_pos_local = log_pos_w - origins

    d = _safe(ee_pos_local - log_pos_local, "d_vec")
    dist = torch.linalg.norm(d, dim=1) if use_l2 else torch.sum(torch.abs(d), dim=1)
    dist = _safe(dist, "dist")

    if shaped:
        rew = 1.0 - torch.tanh(_safe_div(dist, torch.as_tensor(scale, device=device)))
        return _safe(rew, "ee2log_shaped")
    else:
        rew = -_safe_div(dist, torch.as_tensor(scale, device=device))
        return _safe(rew, "ee2log_raw")


# -----------------------------------------------------------------------------
# 动作惩罚：action rate L2（带安全裁剪）
# -----------------------------------------------------------------------------
def safe_action_rate_l2(env, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"), clip_per_step: float = 1.0):
    robot = env.scene[asset_cfg.name]

    # 尽量拿到动作（不同版本字段不同）
    a = None
    try:
        a = env.action_manager.raw_actions
    except Exception:
        pass
    if a is None:
        try:
            a = env.action_manager.processed_actions
        except Exception:
            pass
    if a is None:
        # 退化到 0（不会产生大惩罚）
        a = torch.zeros((env.num_envs, 1), device=env.device, dtype=robot.data.joint_pos.dtype)

    if not torch.is_tensor(a):
        a = torch.as_tensor(a, device=env.device)

    if not hasattr(env, "_prev_actions"):
        env._prev_actions = torch.zeros_like(a)

    da = a - env._prev_actions
    env._prev_actions = a.detach()

    da = torch.nan_to_num(da, nan=0.0, posinf=0.0, neginf=0.0)
    per_env = torch.sum(da * da, dim=1)
    per_env = torch.clamp(per_env, 0.0, clip_per_step)
    return per_env


# -----------------------------------------------------------------------------
# Cabin yaw align（保持你原逻辑）
# -----------------------------------------------------------------------------
def cabin_yaw_aligns_target(env, *, robot_name="robot", log_name="log", eps: float = 1e-6):
    device = env.device
    rob = env.scene[robot_name]
    log = env.scene[log_name]

    def _root_state(data):
        if hasattr(data, "root_state_w"):
            return data.root_state_w
        if hasattr(data, "root_state"):
            return data.root_state
        raise AttributeError("ArticulationData缺少root_state(_w)")

    rs_robot = _root_state(rob.data)  # (N,13)
    rs_log = _root_state(log.data)  # (N,13)

    base_xy = rs_robot[:, 0:2]
    log_xy = rs_log[:, 0:2]
    vec = log_xy - base_xy
    desired = torch.atan2(vec[:, 1], vec[:, 0])

    if not hasattr(env, "_cabin_joint_idx"):
        names = list(rob.data.joint_names)
        idx = -1
        for i, n in enumerate(names):
            s = n.decode("utf-8") if isinstance(n, (bytes, bytearray)) else str(n)
            if s == "revolute_cabin":
                idx = i
                break
        if idx < 0:
            for i, n in enumerate(names):
                s = n.decode("utf-8") if isinstance(n, (bytes, bytearray)) else str(n)
                if "cabin" in s.lower():
                    idx = i
                    break
        env._cabin_joint_idx = int(idx) if idx >= 0 else None
        if env._cabin_joint_idx is None and not hasattr(env, "_warn_no_cabin"):
            print("[WARN] cabin_yaw_aligns_target: 未找到 'revolute_cabin'，奖励将恒为0")
            env._warn_no_cabin = True

    if env._cabin_joint_idx is None:
        return torch.zeros_like(desired)

    jidx = env._cabin_joint_idx
    q = rob.data.joint_pos
    if not torch.is_tensor(q):
        q = torch.as_tensor(q, device=device)
    yaw = q[:, jidx]

    err = (yaw - desired + math.pi) % (2 * math.pi) - math.pi
    return 0.5 * (torch.cos(err).clamp(-1.0, 1.0) + 1.0)

import torch
from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.managers import SceneEntityCfg
from isaaclab.assets import RigidObject
from isaaclab.utils.math import combine_frame_transforms



def move_log_under_command(
    env: ManagerBasedRLEnv,
    env_ids: torch.Tensor,
    command_name: str,
    robot_asset_cfg: SceneEntityCfg,
    log_asset_cfg: SceneEntityCfg,
    log_height: float = 0.04,
) -> None:
    """把 log 移到命令末端正下方，使 log 始终跟随 ee_pose 命令."""
    device = env.device

    # 统一 env_ids 类型
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)

    if env_ids.numel() == 0:
        return

    robot = env.scene[robot_asset_cfg.name]
    log: RigidObject = env.scene[log_asset_cfg.name]  # type: ignore

    # 1) 取当前命令（只取这些 env）
    cmd_all = env.command_manager.get_command(command_name)   # [num_envs, k]
    cmd = cmd_all[env_ids]                                   # [N, k]
    des_pos_b = cmd[:, :3]                                   # [N, 3]

    # 2) 用对应 env 的 root pose 转到世界坐标
    root_pos = robot.data.root_state_w[env_ids, 0:3]         # [N, 3]
    root_quat = robot.data.root_state_w[env_ids, 3:7]        # [N, 4]
    des_pos_w, _ = combine_frame_transforms(
        root_pos,
        root_quat,
        des_pos_b,
    )                                                        # [N, 3]

    # 3) log 中心要比命令点低一半高度
    new_log_pos = des_pos_w.clone()
    #new_log_pos[:, 2] -= 0.5 * log_height



    # 4) 只对这些 env 的 root_state 做修改
    root_state_local = log.data.root_state_w[env_ids].clone()  # [N, 13]
    root_state_local[:, 0:3] = new_log_pos
    root_state_local[:, 7:13] = 0.0  # 线速度/角速度清零

    # 5) 写回仿真（现在 root_state_local 的 batch 维度和 env_ids 匹配）
    log.write_root_state_to_sim(root_state_local, env_ids=env_ids)

import torch
from isaaclab.managers import SceneEntityCfg

def log_height_reward(env, log_asset_cfg: SceneEntityCfg, target_z: float = 0.15):
    log = env.scene[log_asset_cfg.name]
    z = log.data.root_state_w[:, 2]
    # 0~1：超过 target_z 就接近 1
    return torch.clamp(z / float(target_z), 0.0, 1.0)

import torch
from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.managers import SceneEntityCfg

# def _quat_rotate_inv(q_wxyz: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
#     """Rotate vector v by inverse quaternion q (w,x,y,z). v: (N,3)"""
#     qw, qx, qy, qz = q_wxyz[:, 0], q_wxyz[:, 1], q_wxyz[:, 2], q_wxyz[:, 3]
#     # q^{-1} = (w, -x, -y, -z)
#     qx, qy, qz = -qx, -qy, -qz

#     # t = 2 * cross(q_vec, v)
#     t = 2.0 * torch.stack([
#         qy * v[:, 2] - qz * v[:, 1],
#         qz * v[:, 0] - qx * v[:, 2],
#         qx * v[:, 1] - qy * v[:, 0],
#     ], dim=1)
#     # v' = v + w*t + cross(q_vec, t)
#     v_prime = v + qw.unsqueeze(1) * t + torch.stack([
#         qy * t[:, 2] - qz * t[:, 1],
#         qz * t[:, 0] - qx * t[:, 2],
#         qx * t[:, 1] - qy * t[:, 0],
#     ], dim=1)
#     return v_prime

def _quat_rotate_inv(q_wxyz: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    """Rotate v by inverse of quaternion q"""
    q_inv = torch.stack([q_wxyz[:,0], -q_wxyz[:,1], -q_wxyz[:,2], -q_wxyz[:,3]], dim=1)
    return _quat_rotate(q_inv, v)

def sync_ee_pose_to_log_center(
    env: ManagerBasedRLEnv,
    env_ids: torch.Tensor,
    command_name: str,
    robot_asset_cfg: SceneEntityCfg,
    log_asset_cfg: SceneEntityCfg,
    z_offset: float = 0.0,
) -> None:
    """每步把 ee_pose 命令设置为 log 的中心（root frame 表达）"""
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    robot = env.scene[robot_asset_cfg.name]
    log = env.scene[log_asset_cfg.name]

    # log 世界中心
    log_pos_w = log.data.root_state_w[env_ids, 0:3].clone()
    log_pos_w[:, 2] += float(z_offset)

    # robot root 世界位姿
    root_pos_w = robot.data.root_state_w[env_ids, 0:3]
    root_quat_w = robot.data.root_state_w[env_ids, 3:7]  # (w,x,y,z)

    # world -> root: p_b = R(root)^{-1} * (p_w - root_pos)
    v = log_pos_w - root_pos_w
    pos_b = _quat_rotate_inv(root_quat_w, v)

    # 写回命令：命令通常是 root frame 的 (x,y,z,...)，这里只改位置
    cmd = env.command_manager.get_command(command_name)
    cmd[env_ids, 0:3] = pos_b



import torch
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import combine_frame_transforms

def reset_log_near_robot(env, env_ids, robot_asset_cfg: SceneEntityCfg, log_asset_cfg: SceneEntityCfg, offset_b=(0.60, 0.0, -0.09)):
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    robot = env.scene[robot_asset_cfg.name]
    log = env.scene[log_asset_cfg.name]

    root_pos_w = robot.data.root_state_w[env_ids, 0:3]
    root_quat_w = robot.data.root_state_w[env_ids, 3:7]

    offset_b = torch.tensor(offset_b, device=device, dtype=root_pos_w.dtype).view(1, 3).repeat(env_ids.numel(), 1)
    log_pos_w, _ = combine_frame_transforms(root_pos_w, root_quat_w, offset_b)

    rs = log.data.root_state_w[env_ids].clone()   # (M,13)
    rs[:, 0:3] = log_pos_w
    rs[:, 3:7] = torch.tensor([1.0, 0.0, 0.0, 0.0], device=device, dtype=rs.dtype).view(1,4).repeat(env_ids.numel(),1)
    rs[:, 7:13] = 0.0  # 速度清零
    log.write_root_state_to_sim(rs, env_ids=env_ids)

def pull_back_log_if_far(env, env_ids, robot_asset_cfg: SceneEntityCfg, log_asset_cfg: SceneEntityCfg, offset_b=(0.60, 0.0, -0.09), max_dist=0.9):
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    robot = env.scene[robot_asset_cfg.name]
    log = env.scene[log_asset_cfg.name]

    root_pos_w = robot.data.root_state_w[env_ids, 0:3]
    log_pos_w = log.data.root_state_w[env_ids, 0:3]
    dist = torch.linalg.norm(log_pos_w - root_pos_w, dim=1)

    far_mask = dist > float(max_dist)
    if not torch.any(far_mask):
        return

    far_env_ids = env_ids[far_mask]
    reset_log_near_robot(env, far_env_ids, robot_asset_cfg, log_asset_cfg, offset_b=offset_b)


def sync_ee_pose_to_log_center_upright(
    env, env_ids, command_name, robot_asset_cfg, log_asset_cfg,
    z_offset: float = 0.0,
    # 这个是“世界系竖直”的目标姿态。方向不对就换一个常量试（看下面说明）
    world_upright_quat_wxyz=(0.0, 1.0, 0.0, 0.0),
):
    import torch

    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    robot = env.scene[robot_asset_cfg.name]
    log   = env.scene[log_asset_cfg.name]

    log_pos_w = log.data.root_state_w[env_ids, 0:3].clone()
    log_pos_w[:, 2] += float(z_offset)

    root_pos_w  = robot.data.root_state_w[env_ids, 0:3]
    root_quat_w = robot.data.root_state_w[env_ids, 3:7]  # (w,x,y,z)

    # --- quat helpers ---
    def qinv(q):
        return torch.stack([q[:,0], -q[:,1], -q[:,2], -q[:,3]], dim=1)

    def qmul(a,b):
        aw,ax,ay,az = a[:,0],a[:,1],a[:,2],a[:,3]
        bw,bx,by,bz = b[:,0],b[:,1],b[:,2],b[:,3]
        return torch.stack([
            aw*bw-ax*bx-ay*by-az*bz,
            aw*bx+ax*bw+ay*bz-az*by,
            aw*by-ax*bz+ay*bw+az*bx,
            aw*bz+ax*by-ay*bx+az*bw
        ], dim=1)

    # position: world -> root
    v = log_pos_w - root_pos_w
    vq = torch.cat([torch.zeros((v.shape[0],1), device=device, dtype=v.dtype), v], dim=1)
    q_i = qinv(root_quat_w)
    pos_b = qmul(qmul(q_i, vq), root_quat_w)[:,1:4]

    # orientation: q_des_b = inv(q_root_w) ⊗ q_world_des
    q_world = torch.tensor(world_upright_quat_wxyz, device=device, dtype=root_quat_w.dtype).view(1,4).repeat(env_ids.numel(),1)
    q_des_b = qmul(q_i, q_world)

    cmd = env.command_manager.get_command(command_name)
    cmd[env_ids, 0:3] = pos_b
    cmd[env_ids, 3:7] = q_des_b



def _quat_rotate(q_wxyz: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    """Rotate v by quaternion q (w,x,y,z). q:(N,4), v:(N,3)"""
    qw = q_wxyz[:, 0:1]
    qv = q_wxyz[:, 1:4]
    uv = torch.cross(qv, v, dim=1)
    uuv = torch.cross(qv, uv, dim=1)
    return v + 2.0 * (qw * uv + uuv)

def sync_ee_pose_to_log_two_stage(
    env,
    env_ids,
    command_name: str,
    robot_asset_cfg: SceneEntityCfg,
    log_asset_cfg: SceneEntityCfg,
    # ===== 二阶段参数 =====
    approach_height: float = 0.15,     # 先在 log 上方 15cm 悬停靠近（避免贴地）
    descend_xy: float = 0.08,          # XY 距离 < 8cm 才允许下降
    final_z_offset: float = 0.02,      # 最终目标高度：log中心 + 2cm（接近 log 顶面）
    # ===== TCP 用于判断距离（建议填你IK的 body_offset，比如 -0.09）=====
    tcp_offset_local=(0.0, 0.0, -0.09),
    # ===== 姿态锁定（世界系竖直；不对就换常量）=====
    world_upright_quat_wxyz=(0.0, 1.0, 0.0, 0.0),
) -> None:
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    robot = env.scene[robot_asset_cfg.name]
    log   = env.scene[log_asset_cfg.name]

    # --- log world pos ---
    log_pos_w = log.data.root_state_w[env_ids, 0:3]  # (M,3)

    # --- current TCP world pos (用 gripper_frame + tcp_offset_local) ---
    ee_body = (robot_asset_cfg.body_names[0] if getattr(robot_asset_cfg, "body_names", None) else "gripper_frame")
    body_ids, _ = robot.find_bodies([ee_body])
    ee_idx = int(body_ids[0])

    ee_pos_w  = robot.data.body_state_w[env_ids, ee_idx, 0:3]
    ee_quat_w = robot.data.body_state_w[env_ids, ee_idx, 3:7]

    off = torch.tensor(tcp_offset_local, device=device, dtype=ee_pos_w.dtype).view(1,3).repeat(env_ids.numel(), 1)
    tcp_pos_w = ee_pos_w + _quat_rotate(ee_quat_w, off)

    # --- 二阶段：先抬高 approach_height 靠近，再下降到 final_z_offset ---
    d_xy = torch.linalg.norm((tcp_pos_w - log_pos_w)[:, 0:2], dim=1)
    target_pos_w = log_pos_w.clone()
    z_far  = log_pos_w[:, 2] + float(approach_height)
    z_near = log_pos_w[:, 2] + float(final_z_offset)
    target_pos_w[:, 2] = torch.where(d_xy > float(descend_xy), z_far, z_near)

    # --- world -> root frame ---
    root_pos_w  = robot.data.root_state_w[env_ids, 0:3]
    root_quat_w = robot.data.root_state_w[env_ids, 3:7]
    pos_b = _quat_rotate_inv(root_quat_w, target_pos_w - root_pos_w)

    # --- orientation: q_des_b = inv(q_root_w) ⊗ q_world ---
    q_world = torch.tensor(world_upright_quat_wxyz, device=device, dtype=root_quat_w.dtype).view(1,4).repeat(env_ids.numel(), 1)
    q_des_b = _quat_mul(_quat_inv(root_quat_w), q_world)

    # --- write command buffer ---
    cmd = env.command_manager.get_command(command_name)
    cmd[env_ids, 0:3] = pos_b
    if cmd.shape[1] >= 7:
        cmd[env_ids, 3:7] = q_des_b
import torch
from isaaclab.managers import SceneEntityCfg

def keep_gripper_vertical(
    env,
    env_ids,
    asset_cfg: SceneEntityCfg,
    pitch_chain_joints: list[str],
    wrist_joint: str,
    pitch_des: float = -1.57079632679,
    pitch0: float = 0.0,
):
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    robot = env.scene[asset_cfg.name]

    # --- cache joint ids ---
    if not hasattr(env, "_keep_vert_joint_ids"):
        names = [n.decode() if isinstance(n,(bytes,bytearray)) else str(n) for n in robot.data.joint_names]
        chain_ids = [names.index(jn) for jn in pitch_chain_joints]
        wrist_id = names.index(wrist_joint)
        env._keep_vert_joint_ids = (chain_ids, wrist_id)

    chain_ids, wrist_id = env._keep_vert_joint_ids

    q = robot.data.joint_pos[env_ids]   # (M, DoF)

    # pitch_total ≈ q_lift + q_tilt + q_scoop + q_wrist + pitch0
    chain_sum = torch.zeros((env_ids.numel(),), device=device, dtype=q.dtype)
    for jid in chain_ids:
        chain_sum = chain_sum + q[:, jid]

    q_wrist_des = float(pitch_des) - chain_sum - float(pitch0)   # (M,)

    # --- joint limits: prefer joint_pos_limits, fallback to joint_limits ---
    limits_all = None
    if hasattr(robot.data, "joint_pos_limits"):
        limits_all = robot.data.joint_pos_limits
    elif hasattr(robot.data, "joint_limits"):
        limits_all = robot.data.joint_limits

    if limits_all is not None:
        if limits_all.ndim == 2:
            lo = limits_all[wrist_id, 0].to(device=device, dtype=q.dtype).expand(env_ids.numel())
            hi = limits_all[wrist_id, 1].to(device=device, dtype=q.dtype).expand(env_ids.numel())
        elif limits_all.ndim == 3:
            lo = limits_all[env_ids, wrist_id, 0].to(device=device, dtype=q.dtype)
            hi = limits_all[env_ids, wrist_id, 1].to(device=device, dtype=q.dtype)
        else:
            raise RuntimeError(f"Unexpected joint_pos_limits/joint_limits shape: {limits_all.shape}")

        q_wrist_des = torch.clamp(q_wrist_des, lo, hi)

    # ------------------------------------------------------------------
    # APPLY: try target API first; if not available, fallback to write_joint_state
    # ------------------------------------------------------------------

    # 1) Try set_joint_position_target (many versions have this)
    if hasattr(robot, "set_joint_position_target"):
        try:
            # some versions accept (targets, env_ids=...)
            # targets can be full DoF array; we write only wrist in a copy
            q_tgt = robot.data.joint_pos[env_ids].clone()
            q_tgt[:, wrist_id] = q_wrist_des
            robot.set_joint_position_target(q_tgt, env_ids=env_ids)
            return
        except TypeError:
            try:
                q_tgt = robot.data.joint_pos[env_ids].clone()
                q_tgt[:, wrist_id] = q_wrist_des
                robot.set_joint_position_target(q_tgt, env_ids)
                return
            except Exception:
                pass
        except Exception:
            pass

    # 2) Fallback: dire
import torch
from isaaclab.managers import SceneEntityCfg

# ---------------- quaternion utils (w,x,y,z) ----------------
def _quat_norm(q):
    return q / (torch.linalg.norm(q, dim=1, keepdim=True) + 1e-8)

def _quat_mul(a, b):
    aw, ax, ay, az = a[:,0], a[:,1], a[:,2], a[:,3]
    bw, bx, by, bz = b[:,0], b[:,1], b[:,2], b[:,3]
    return torch.stack([
        aw*bw - ax*bx - ay*by - az*bz,
        aw*bx + ax*bw + ay*bz - az*by,
        aw*by - ax*bz + ay*bw + az*bx,
        aw*bz + ax*by - ay*bx + az*bw,
    ], dim=1)

def _quat_inv(q):
    return torch.stack([q[:,0], -q[:,1], -q[:,2], -q[:,3]], dim=1)

def _quat_slerp(q0, q1, t):
    # q0,q1: (N,4), t:(N,) in [0,1]
    q0 = _quat_norm(q0)
    q1 = _quat_norm(q1)
    dot = torch.sum(q0*q1, dim=1, keepdim=True)

    # take shortest path
    q1 = torch.where(dot < 0.0, -q1, q1)
    dot = torch.abs(dot).clamp(0.0, 1.0)

    # if very close -> lerp
    close = (dot > 0.9995).squeeze(1)
    t_ = t.view(-1,1)

    theta_0 = torch.acos(dot)                   # (N,1)
    sin_0 = torch.sin(theta_0).clamp(1e-8, 1e8) # (N,1)
    theta = theta_0 * t_
    s0 = torch.sin(theta_0 - theta) / sin_0
    s1 = torch.sin(theta) / sin_0
    out = s0*q0 + s1*q1

    # fallback lerp for close
    lerp = _quat_norm((1.0 - t_)*q0 + t_*q1)
    out = torch.where(close.view(-1,1), lerp, out)
    return _quat_norm(out)

def _yaw_from_quat(q):
    # q: (N,4) wxyz -> yaw around world z
    w,x,y,z = q[:,0], q[:,1], q[:,2], q[:,3]
    t0 = 2.0*(w*z + x*y)
    t1 = 1.0 - 2.0*(y*y + z*z)
    return torch.atan2(t0, t1)

def _quat_from_yaw(yaw, device, dtype):
    # roll=pitch=0
    cy = torch.cos(0.5*yaw)
    sy = torch.sin(0.5*yaw)
    return torch.stack([cy, torch.zeros_like(cy), torch.zeros_like(cy), sy], dim=1).to(device=device, dtype=dtype)

# ---------------- main sync ----------------
def sync_ee_pose_to_log_two_stage_pose_align(
    env,
    env_ids,
    command_name: str,
    robot_asset_cfg: SceneEntityCfg,
    log_asset_cfg: SceneEntityCfg,

    # --- position staging ---
    approach_height: float = 0.15,   # 先在 log 上方 15cm 对齐
    descend_xy: float = 0.08,        # XY < 8cm 才允许下落
    final_z_offset: float = 0.02,    # 最终目标=log中心 + 2cm（更接近上表面）

    # --- orientation alignment staging ---
    align_start_xy: float = 0.25,    # XY < 25cm 开始旋转对齐
    align_mode: str = "yaw",         # "yaw" 或 "full"
    upright_quat_wxyz=(0.0, 1.0, 0.0, 0.0),  # 你之前竖直用的那个；若不对可换

    # --- gripper<->log 固定零偏（用于 full 对齐时微调）---
    gripper_in_log_quat_wxyz=(1.0, 0.0, 0.0, 0.0),
):
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    robot = env.scene[robot_asset_cfg.name]
    log   = env.scene[log_asset_cfg.name]

    # --- log pose world ---
    log_pos_w  = log.data.root_state_w[env_ids, 0:3]
    log_quat_w = log.data.root_state_w[env_ids, 3:7]

    # --- current ee pose world (for smooth slerp start) ---
    ee_body = (robot_asset_cfg.body_names[0] if getattr(robot_asset_cfg, "body_names", None) else "gripper_frame")
    body_ids, _ = robot.find_bodies([ee_body])
    ee_idx = int(body_ids[0])
    ee_pos_w  = robot.data.body_state_w[env_ids, ee_idx, 0:3]
    ee_quat_w = robot.data.body_state_w[env_ids, ee_idx, 3:7]

    # --- stage position ---
    d_xy = torch.linalg.norm((ee_pos_w - log_pos_w)[:, 0:2], dim=1)  # (M,)
    target_pos_w = log_pos_w.clone()
    z_far  = log_pos_w[:, 2] + float(approach_height)
    z_near = log_pos_w[:, 2] + float(final_z_offset)
    target_pos_w[:, 2] = torch.where(d_xy > float(descend_xy), z_far, z_near)

    # --- stage orientation target in world ---
    upright = torch.tensor(upright_quat_wxyz, device=device, dtype=ee_quat_w.dtype).view(1,4).repeat(env_ids.numel(), 1)
    if align_mode == "full":
        q_off = torch.tensor(gripper_in_log_quat_wxyz, device=device, dtype=ee_quat_w.dtype).view(1,4).repeat(env_ids.numel(), 1)
        q_align = _quat_mul(log_quat_w, q_off)           # gripper axes ~ log axes
    else:
        yaw = _yaw_from_quat(log_quat_w)
        q_align = _quat_from_yaw(yaw, device, ee_quat_w.dtype)
        # 这里把 yaw 对齐到 log，但 roll/pitch 仍用 upright（避免跟着 log 翻滚）

    # --- compute blend alpha: far->upright, near->align ---
    # alpha = 0 when d_xy >= align_start_xy, alpha = 1 when d_xy <= descend_xy
    a = (float(align_start_xy) - d_xy) / max(float(align_start_xy - descend_xy), 1e-6)
    alpha = torch.clamp(a, 0.0, 1.0)

    # 先保持 upright，再逐渐对齐（你会看到“旋转对齐过程”）
    q_target_w = _quat_slerp(upright, q_align, alpha)

    # --- world -> root frame (for command buffer) ---
    root_pos_w  = robot.data.root_state_w[env_ids, 0:3]
    root_quat_w = robot.data.root_state_w[env_ids, 3:7]

    # pos_b = inv(root_q) rotate (target_pos_w-root_pos_w)
    # 用 quat 旋转向量：v' = q^-1 * (0,v) * q
    v = target_pos_w - root_pos_w
    vq = torch.cat([torch.zeros((env_ids.numel(),1), device=device, dtype=v.dtype), v], dim=1)
    pos_b = _quat_mul(_quat_mul(_quat_inv(root_quat_w), vq), root_quat_w)[:, 1:4]

    # q_b = inv(root_q) * q_w
    q_target_b = _quat_mul(_quat_inv(root_quat_w), q_target_w)

    # --- write into command ---
    cmd = env.command_manager.get_command(command_name)
    cmd[env_ids, 0:3] = pos_b
    if cmd.shape[1] >= 7:
        cmd[env_ids, 3:7] = _quat_norm(q_target_b)


import torch
from isaaclab.managers import SceneEntityCfg

def _wrap_to_pi(x):
    return (x + torch.pi) % (2 * torch.pi) - torch.pi

def _yaw_from_quat_wxyz(q):
    # q: (N,4) wxyz
    w,x,y,z = q[:,0], q[:,1], q[:,2], q[:,3]
    t0 = 2.0*(w*z + x*y)
    t1 = 1.0 - 2.0*(y*y + z*z)
    return torch.atan2(t0, t1)

def _quat_from_yaw_wxyz(yaw, dtype, device):
    cy = torch.cos(0.5*yaw).to(dtype=dtype, device=device)
    sy = torch.sin(0.5*yaw).to(dtype=dtype, device=device)
    return torch.stack([cy, torch.zeros_like(cy), torch.zeros_like(cy), sy], dim=1)

def _quat_mul_wxyz(a, b):
    aw, ax, ay, az = a[:,0], a[:,1], a[:,2], a[:,3]
    bw, bx, by, bz = b[:,0], b[:,1], b[:,2], b[:,3]
    return torch.stack([
        aw*bw - ax*bx - ay*by - az*bz,
        aw*bx + ax*bw + ay*bz - az*by,
        aw*by - ax*bz + ay*bw + az*bx,
        aw*bz + ax*by - ay*bx + az*bw,
    ], dim=1)

def _quat_inv_wxyz(q):
    return torch.stack([q[:,0], -q[:,1], -q[:,2], -q[:,3]], dim=1)

def _quat_rotate_vec_wxyz(q, v):
    # v: (N,3) -> rotate by q (wxyz)
    vq = torch.cat([torch.zeros((v.shape[0],1), device=v.device, dtype=v.dtype), v], dim=1)
    return _quat_mul_wxyz(_quat_mul_wxyz(q, vq), _quat_inv_wxyz(q))[:, 1:4]


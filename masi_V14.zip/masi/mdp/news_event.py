from __future__ import annotations
import math
import torch
from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import (
    subtract_frame_transforms,
    quat_from_angle_axis,
    quat_mul,
    matrix_from_quat,
    quat_from_euler_xyz,
    quat_slerp,
)

# ----------------------------------------------------------
# 辅助函数
# ----------------------------------------------------------
def _yaw_from_quat_wxyz(q: torch.Tensor) -> torch.Tensor:
    """从四元数计算 yaw 角"""
    w, x, y, z = q.unbind(-1)
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    return torch.atan2(siny_cosp, cosy_cosp)


def _wrap_to_pi(a: torch.Tensor) -> torch.Tensor:
    """限制角度到 [-pi, pi]"""
    return (a + math.pi) % (2.0 * math.pi) - math.pi


def _clamp_step(vec: torch.Tensor, max_step: float) -> torch.Tensor:
    """对 3D 向量做每步最大位移裁剪"""
    n = torch.linalg.norm(vec, dim=-1, keepdim=True).clamp_min(1e-9)
    scale = torch.clamp(torch.tensor(max_step, device=vec.device, dtype=vec.dtype) / n, max=1.0)
    return vec * scale


# ----------------------------------------------------------
# 状态重置
# ----------------------------------------------------------
@torch.no_grad()
def reset_sync_ee_pose_state(env: ManagerBasedRLEnv, env_ids: torch.Tensor):
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    # stage: 0=approach, 1=descend(锁存)
    if hasattr(env, "_sync_stage"):
        env._sync_stage[env_ids] = 0
    if hasattr(env, "_sync_prev_pos_b"):
        env._sync_prev_pos_b[env_ids] = 0.0
    if hasattr(env, "_sync_prev_yaw_b"):
        env._sync_prev_yaw_b[env_ids] = 0.0


# ----------------------------------------------------------
# 主同步函数  V13 
# ----------------------------------------------------------
# @torch.no_grad()
# def sync_ee_pose_to_log_upright_yaw_two_stage(
#     env,
#     env_ids: torch.Tensor,
#     command_name: str,
#     robot_asset_cfg,
#     log_asset_cfg,
#     approach_height: float = 0.10,
#     descend_xy: float = 0.06,
#     final_z_offset: float = 0.0,
#     align_start_xy: float = 0.25,
#     yaw_offset: float = 0.0,
#     upright_base_quat_wxyz=(1.0, 0.0, 0.0, 0.0),
#     tcp_offset_local=(0.0, 0.0, -0.09),
#     # --- 新增参数 ---
#     snap_dist: float = 0.20,
#     max_pos_step: float = 0.03,
#     move_threshold: float = 0.02,   # log 移动阈值
#     cooldown_steps: int = 5,        # 冷却帧数
#     blend: float = 0.2              # 平滑融合比例
# ):
#     device = env.device
#     robot = env.scene[robot_asset_cfg.name]
#     log = env.scene[log_asset_cfg.name]

#     # ----------------------------------------------------------------------
#     # log movement filtering (冷却机制)
#     # ----------------------------------------------------------------------
#     if not hasattr(env, "_log_prev_pos"):
#         env._log_prev_pos = torch.zeros_like(log.data.root_pos_w)
#         env._log_stable_counter = torch.zeros(log.data.root_pos_w.shape[0], dtype=torch.long, device=device)

#     log_pos_cur = log.data.root_pos_w[:, :3]
#     moved = torch.linalg.norm(log_pos_cur - env._log_prev_pos[:, :3], dim=1) > move_threshold
#     env._log_stable_counter[moved] = 0
#     env._log_stable_counter += 1
#     env._log_prev_pos[:, :3] = log_pos_cur

#     valid_mask = env._log_stable_counter >= cooldown_steps
#     valid_envs = env_ids[valid_mask[env_ids]]
#     if valid_envs.numel() == 0:
#         return

#     # ----------------------------------------------------------------------
#     # compute desired pose relative to robot base
#     # ----------------------------------------------------------------------
#     log_pos_w = log.data.root_pos_w[valid_envs, :3]
#     base_pos_w = robot.data.root_state_w[valid_envs, 0:3]
#     des_pos_b = log_pos_w - base_pos_w
#     des_pos_b[:, 2] += final_z_offset

#     # hover → descend phase
#     cmd = env.command_manager.get_command(command_name)
#     cur_pos_b = cmd[valid_envs, 0:3]
#     delta_xy = des_pos_b[:, 0:2] - cur_pos_b[:, 0:2]
#     dist_xy = torch.linalg.norm(delta_xy, dim=1)

#     hover_pos_b = des_pos_b.clone()
#     hover_pos_b[:, 2] += approach_height

#     target_pos_b = torch.where(
#         (dist_xy > descend_xy).unsqueeze(1),
#         hover_pos_b,
#         des_pos_b,
#     )

#     # ----------------------------------------------------------------------
#     # position update (snap + smooth)
#     # ----------------------------------------------------------------------
#     delta = target_pos_b - cur_pos_b
#     dist = torch.linalg.norm(delta, dim=1)

#     # far → snap
#     far_mask = dist > snap_dist
#     if far_mask.any():
#         cur_pos_b[far_mask] = target_pos_b[far_mask]

#     # near → limited step
#     near_mask = ~far_mask
#     if near_mask.any():
#         step = delta[near_mask]
#         step_len = torch.linalg.norm(step, dim=1, keepdim=True).clamp(min=1e-8)
#         step = step * torch.clamp(max_pos_step / step_len, max=1.0)
#         cur_pos_b[near_mask] += step

#     new_pos_b = cur_pos_b

#     # ----------------------------------------------------------------------
#     # orientation: 保持竖直 + yaw 对齐
#     # ----------------------------------------------------------------------
#     upright_quat_w = torch.tensor(upright_base_quat_wxyz, device=device, dtype=torch.float32).repeat(len(valid_envs), 1)

#     # 正确的 yaw 张量输入 (N,1)
#     roll = torch.zeros(len(valid_envs), 1, device=device)
#     pitch = torch.zeros(len(valid_envs), 1, device=device)
#     yaw = torch.full((len(valid_envs), 1), yaw_offset, device=device)

#     yaw_quat = quat_from_euler_xyz(roll, pitch, yaw).view(len(valid_envs), 4)
#     new_quat_b = quat_mul(upright_quat_w, yaw_quat)

#     # ----------------------------------------------------------------------
#     # smooth blend (平滑融合)
#     # ----------------------------------------------------------------------
#     # ----------------------------------------------------------------------
#     # smooth blend (平滑融合)
#     # ----------------------------------------------------------------------
#     prev_pos = cmd[valid_envs, 0:3]
#     prev_quat = cmd[valid_envs, 3:7]

#     blended_pos = prev_pos * (1 - blend) + new_pos_b * blend

#     # --- 批量四元数球面插值 (手动替代 IsaacLab quat_slerp) ---
#     dot = torch.sum(prev_quat * new_quat_b, dim=1, keepdim=True)
#     dot = torch.clamp(dot, -1.0, 1.0)
#     theta = torch.acos(dot) * blend
#     rel = new_quat_b - prev_quat * dot
#     rel = torch.nn.functional.normalize(rel, dim=1)
#     blended_quat = prev_quat * torch.cos(theta) + rel * torch.sin(theta)
#     blended_quat = torch.nn.functional.normalize(blended_quat, dim=1)

#     # ----------------------------------------------------------------------
#     # write back to command buffer
#     # ----------------------------------------------------------------------
#     cmd[valid_envs, 0:3] = blended_pos
#     cmd[valid_envs, 3:7] = blended_quat

# ----------------------------------------------------------
# 主同步函数  V14 
# ----------------------------------------------------------


# 你原本用到的 quat_from_euler_xyz / quat_mul 请确保已 import
# from isaaclab.utils.math import quat_from_euler_xyz, quat_mul

@torch.no_grad()
def sync_ee_pose_to_log_upright_yaw_two_stage(
    env,
    env_ids: torch.Tensor,
    command_name: str,
    robot_asset_cfg,
    log_asset_cfg,
    approach_height: float = 0.10,
    descend_xy: float = 0.06,
    final_z_offset: float = 0.0,
    align_start_xy: float = 0.25,
    yaw_offset: float = 0.0,
    upright_base_quat_wxyz=(1.0, 0.0, 0.0, 0.0),
    tcp_offset_local=(0.0, 0.0, -0.09),
    snap_dist: float = 0.20,
    max_pos_step: float = 0.03,
    move_threshold: float = 0.02,
    cooldown_steps: int = 5,
    blend: float = 0.2,
    # ✅ 新增：lift 抬高多少（phase==2 时）
    lift_z: float = 0.18,
):
    device = env.device
    robot = env.scene[robot_asset_cfg.name]
    log = env.scene[log_asset_cfg.name]

    # env_ids 兼容 slice
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    # ----------------------------------------------------------------------
    # log movement filtering (冷却机制) + ✅ phase>=1 绕过
    # ----------------------------------------------------------------------
    if not hasattr(env, "_log_prev_pos"):
        env._log_prev_pos = torch.zeros_like(log.data.root_pos_w)
        env._log_stable_counter = torch.zeros(log.data.root_pos_w.shape[0], dtype=torch.long, device=device)

    log_pos_cur = log.data.root_pos_w[:, :3]
    moved = torch.linalg.norm(log_pos_cur - env._log_prev_pos[:, :3], dim=1) > move_threshold
    env._log_stable_counter[moved] = 0
    env._log_stable_counter += 1
    env._log_prev_pos[:, :3] = log_pos_cur

    valid_mask = env._log_stable_counter >= cooldown_steps

    # ✅ 如果 close/lift 阶段：不要被 cooldown 卡住
    if hasattr(env, "_grasp_phase"):
        valid_mask = valid_mask | (env._grasp_phase >= 1)

    valid_envs = env_ids[valid_mask[env_ids]]
    if valid_envs.numel() == 0:
        return

    # ----------------------------------------------------------------------
    # compute desired pose (base-translation frame)
    # ----------------------------------------------------------------------
    log_pos_w = log.data.root_pos_w[valid_envs, :3]
    base_pos_w = robot.data.root_state_w[valid_envs, 0:3]

    des_pos_b = log_pos_w - base_pos_w
    des_pos_b[:, 2] += final_z_offset

    # hover → descend
    cmd = env.command_manager.get_command(command_name)
    cur_pos_b = cmd[valid_envs, 0:3]
    delta_xy = des_pos_b[:, 0:2] - cur_pos_b[:, 0:2]
    dist_xy = torch.linalg.norm(delta_xy, dim=1)

    hover_pos_b = des_pos_b.clone()
    hover_pos_b[:, 2] += approach_height

    target_pos_b = torch.where(
        (dist_xy > descend_xy).unsqueeze(1),
        hover_pos_b,
        des_pos_b,
    )

    # ----------------------------------------------------------------------
    # ✅ phase override：close/lift 锁 XY；lift 抬 Z
    # ----------------------------------------------------------------------
    if hasattr(env, "_grasp_phase") and hasattr(env, "_lock_xy"):
        phase = env._grasp_phase[valid_envs]  # (K,)

        mask_hold = phase >= 1
        if mask_hold.any():
            # lock_xy 是 world XY -> 转为 base-translation frame：减 base_pos_w
            lock_xy_w = env._lock_xy[valid_envs[mask_hold]]          # (M,2) world
            lock_xy_b = lock_xy_w - base_pos_w[mask_hold, 0:2]       # (M,2) base frame(平移)
            target_pos_b[mask_hold, 0:2] = lock_xy_b

        mask_lift = phase == 2
        if mask_lift.any():
            # lift：在当前目标基础上抬高
            target_pos_b[mask_lift, 2] = des_pos_b[mask_lift, 2] + float(lift_z)

    # ----------------------------------------------------------------------
    # position update (snap + limited step)
    # ----------------------------------------------------------------------
    delta = target_pos_b - cur_pos_b
    dist = torch.linalg.norm(delta, dim=1)

    far_mask = dist > snap_dist
    if far_mask.any():
        cur_pos_b[far_mask] = target_pos_b[far_mask]

    near_mask = ~far_mask
    if near_mask.any():
        step = delta[near_mask]
        step_len = torch.linalg.norm(step, dim=1, keepdim=True).clamp(min=1e-8)
        step = step * torch.clamp(max_pos_step / step_len, max=1.0)
        cur_pos_b[near_mask] += step

    new_pos_b = cur_pos_b

    # ----------------------------------------------------------------------
    # orientation: 竖直 + yaw_offset
    # ----------------------------------------------------------------------
    upright_quat_w = torch.tensor(upright_base_quat_wxyz, device=device, dtype=torch.float32).repeat(len(valid_envs), 1)
    roll = torch.zeros(len(valid_envs), 1, device=device)
    pitch = torch.zeros(len(valid_envs), 1, device=device)
    yaw = torch.full((len(valid_envs), 1), yaw_offset, device=device)

    yaw_quat = quat_from_euler_xyz(roll, pitch, yaw).view(len(valid_envs), 4)
    new_quat_b = quat_mul(upright_quat_w, yaw_quat)

    # ----------------------------------------------------------------------
    # blend
    # ----------------------------------------------------------------------
    prev_pos = cmd[valid_envs, 0:3]
    prev_quat = cmd[valid_envs, 3:7]

    blended_pos = prev_pos * (1 - blend) + new_pos_b * blend

    dot = torch.sum(prev_quat * new_quat_b, dim=1, keepdim=True)
    dot = torch.clamp(dot, -1.0, 1.0)
    theta = torch.acos(dot) * blend
    rel = new_quat_b - prev_quat * dot
    rel = torch.nn.functional.normalize(rel, dim=1)
    blended_quat = prev_quat * torch.cos(theta) + rel * torch.sin(theta)
    blended_quat = torch.nn.functional.normalize(blended_quat, dim=1)

    # write back
    cmd[valid_envs, 0:3] = blended_pos
    cmd[valid_envs, 3:7] = blended_quat

from __future__ import annotations

import math
import torch
# mdp.py 里加上：

from isaaclab.envs import ManagerBasedEnv

from isaaclab.managers import SceneEntityCfg

from isaaclab.utils.math import matrix_from_quat

def reset_log_radial(
    env,
    distance_range: tuple[float, float] = (0.4, 0.6),
    yaw_range: tuple[float, float] = (-math.pi, math.pi),
    z_height: float = 0.03,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("log"),
) -> None:
    """Reset the log object around the robot in a 360-degree ring with random yaw.

    - Samples radius uniformly in [r_min, r_max] and angle uniformly in [-pi, pi].
    - Places the log center at that XY relative to the robot root, with fixed Z height.
    - Sets roll=pitch=0, yaw=random, i.e., the log lies on the ground with Z-up.
    """
    scene = env.scene
    robot = scene["robot"]
    log = scene[asset_cfg.name]

    num_envs = scene.num_envs
    device = robot.device

    # Robot roots in world
    root_w = robot.data.root_state_w[:, :7]

    r_min, r_max = distance_range
    th_min, th_max = yaw_range

    # Sample polar coordinates
    radii = torch.empty((num_envs,), device=device).uniform_(r_min, r_max)
    thetas = torch.empty((num_envs,), device=device).uniform_(th_min, th_max)

    # Positions relative to robot base (in its local XY) then map to world
    # Compute world basis from base orientation
    R_bw = env.scene["robot"].data.root_quat_w
    # Use matrix conversion
    from isaaclab.utils.math import matrix_from_quat

    R_bw_m = matrix_from_quat(root_w[:, 3:7])
    xy_local = torch.stack([torch.cos(thetas) * radii, torch.sin(thetas) * radii, torch.zeros_like(radii)], dim=1)
    xy_world = torch.bmm(R_bw_m, xy_local.unsqueeze(-1)).squeeze(-1)

    # Final world positions
    pos_w = root_w[:, :3] + xy_world
    pos_w[:, 2] = z_height

    # Orientations: Z-up with random yaw around Z
    # quaternion from yaw
    half = thetas * 0.5
    yaw_quat = torch.stack([torch.cos(half), torch.zeros_like(half), torch.zeros_like(half), torch.sin(half)], dim=1)

    # Write root state
    log.write_root_pose_to_sim(pos_w, yaw_quat)

# utils_pose.py (or inside mdp)

def compose_world_pose_from_local(origins, local_pos, local_quat):
    """
    origins: [N,3] env origins in meters
    local_pos: [K,3] positions in *env-local* frame (same env_ids indexing)
    local_quat: [K,4] unit quats (wxyz) in *env-local* frame
    returns world_pos, world_quat (same shapes)
    """
    world_pos = origins + local_pos
    world_quat = local_quat  # no env rotation in Masi grid -> passthrough
    return world_pos, world_quat
# mdp.py  (or wherever your mdp functions live)


@torch.no_grad()
def auto_close_gripper_near_log(
    env,
    dt,  # ★★★ 关键：step 事件需要 (env, dt)
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    log_cfg: SceneEntityCfg   = SceneEntityCfg("log"),
    claw_regex: str = r"revolute_claw_.*",
    ee_body_name: str = "gripper_frame",
    ee_offset_local=(0.0, 0.0, -0.09),   # 与 ActionsCfg.body_offset 对齐
    near_thresh: float = 0.045,          # 4.5cm 以内视为“接近”
    hysteresis: float = 0.01,            # 滞回，防止抖动
    close_cmd: float = 0.0,
    open_cmd: float  = 0.20,
):
    scene = env.scene
    robot = scene[robot_cfg.name]
    log   = scene[log_cfg.name]
    dev   = env.device

    # 爪子关节 ids
    claw_joint_ids, _ = robot.find_joints([claw_regex])

    # 末端位姿（带 offset）
    body_ids, _ = robot.find_bodies([ee_body_name])
    if len(body_ids) == 0:
        return  # 没找到指定刚体就跳过
    b_id = int(body_ids[0])

    ee_p  = robot.data.body_link_pos_w[:, b_id, :]   # (N,3)
    ee_q  = robot.data.body_link_quat_w[:, b_id, :]  # (N,4)
    R     = matrix_from_quat(ee_q)                   # (N,3,3)
    off   = torch.as_tensor(ee_offset_local, device=dev, dtype=ee_p.dtype).view(1,3,1)
    ee_tip= ee_p + (R @ off).squeeze(-1)             # (N,3)

    # log 根位置
    log_p = log.data.root_pos_w[:, :3]               # (N,3)

    # 用 env 原点做本地化，避免巨大 world 坐标引入数值误差
    origins = scene.env_origins
    if not torch.is_tensor(origins):
        origins = torch.as_tensor(origins, device=dev, dtype=ee_p.dtype)

    d = (ee_tip - origins) - (log_p - origins)
    dist = torch.linalg.norm(d, dim=-1)              # (N,)

    # 带滞回的“近/远”状态
    if not hasattr(env, "_auto_grip_state"):
        env._auto_grip_state = torch.zeros_like(dist, dtype=torch.bool, device=dev)
    close_now = (dist < near_thresh) | (env._auto_grip_state & (dist < near_thresh + hysteresis))
    env._auto_grip_state = close_now

    # 下达爪子目标
    tgt = torch.where(close_now, torch.full_like(dist, close_cmd), torch.full_like(dist, open_cmd))
    if len(claw_joint_ids) == 0:
        return
    tgt_expanded = tgt.view(-1, 1).repeat(1, len(claw_joint_ids))  # (N, num_claw)
    robot.set_joint_position_target(tgt_expanded, joint_ids=claw_joint_ids)

# --- ring reset for "log" ----------------------------------------------------

def _yaw_to_quat(yaw: torch.Tensor):
    half = 0.5 * yaw
    return torch.stack([torch.cos(half), torch.zeros_like(yaw), torch.zeros_like(yaw), torch.sin(half)], dim=-1)

def reset_log_pose_on_ring(env, env_ids, *,
                           asset_cfg: SceneEntityCfg,
                           radius=(0.14, 0.22),
                           theta=(-math.pi, math.pi),
                           z=0.03,
                           yaw_mode: str = "tangent"):
    device = env.device
    env_ids = torch.as_tensor(env_ids if env_ids is not None else torch.arange(env.scene.num_envs, device=device),
                              device=device, dtype=torch.long)
    n = env_ids.numel()
    if n == 0: return
    r  = torch.empty(n, device=device).uniform_(*radius)
    th = torch.empty(n, device=device).uniform_(*theta)

    # 局部环形坐标
    pos_local = torch.stack([r*torch.cos(th), r*torch.sin(th), torch.full((n,), z, device=device)], dim=-1)

    # 加每个 env 的平铺偏移（不要堆在 (0,0)）
    if hasattr(env.scene, "env_origins"):
        pos = pos_local.clone()
        pos[:, 0:2] += env.scene.env_origins[env_ids, 0:2]
    else:
        pos = pos_local

    # 朝向：切向/径向/固定
    if yaw_mode == "tangent":
        yaw = th + math.pi*0.5
    elif yaw_mode == "radial":
        yaw = th
    else:
        yaw = torch.zeros_like(th)
    rot = _yaw_to_quat(yaw)

    entity = env.scene[asset_cfg.name]
    root_state = (entity.data.root_state_w.clone()
                  if hasattr(entity.data, "root_state_w")
                  else entity.data.default_root_state.clone())
    root_state[env_ids, 0:3] = pos
    root_state[env_ids, 3:7] = rot
    root_state[env_ids, 7:13] = 0.0

    # 写回（兼容两种写法）
    if hasattr(entity, "set_root_state"):
        try: entity.set_root_state(root_state)
        except TypeError: pass
    if hasattr(entity, "write_root_state_to_sim"):
        try: entity.write_root_state_to_sim(root_state)
        except TypeError:
            if hasattr(entity.data, "root_state_w"):
                entity.data.root_state_w[:] = root_state
            entity.write_root_state_to_sim()

def log_dir_in_base(env, *, robot_name="robot", log_name="log"):
    rob = env.scene[robot_name]
    lg  = env.scene[log_name]

    # —— 安全拿 root_state（不同版本字段名不同）——
    rsr = getattr(rob.data, "root_state_w", None)
    if rsr is None:
        rsr = rob.data.root_state                #

    rsl = getattr(lg.data, "root_state_w", None)
    if rsl is None:
        rsl = lg.data.root_state

    # 位置（世界系）
    base_xy = rsr[:, 0:2]
    log_xy  = rsl[:, 0:2]
    v = log_xy - base_xy
    dist = torch.linalg.norm(v, dim=1).clamp_min(1e-6)  # 避免除零

    # 从四元数(w,x,y,z)取底座yaw
    qw, qx, qy, qz = rsr[:, 3], rsr[:, 4], rsr[:, 5], rsr[:, 6]
    yaw_base = torch.atan2(2*(qw*qz + qx*qy), 1 - 2*(qy*qy + qz*qz))

    # 目标世界系方位角 & 与底座yaw差
    dir_world = torch.atan2(v[:, 1], v[:, 0])
    yaw_rel = (dir_world - yaw_base + math.pi) % (2*math.pi) - math.pi  # (-pi, pi]

    # 归一化方向 + 距离 + 相对yaw（4维）
    dxn = v[:, 0] / dist
    dyn = v[:, 1] / dist
    return torch.stack([dxn, dyn, dist, yaw_rel], dim=1)


# def auto_grasp_log_fsm(
#     env: ManagerBasedRLEnv,
#     env_ids: torch.Tensor,
#     robot_asset_cfg: SceneEntityCfg,
#     log_asset_cfg: SceneEntityCfg,
#     close_dist: float,
#     lift_height: float,
#     open_action: float,
#     close_action: float,
# ) -> None:
#     """
#     规则 + RL 的自动抓取逻辑（作为 EventTerm 使用）。

#     状态机定义（每个 env 一条）:
#         0: OPEN     - 爪子张开
#         1: CLOSING  - 末端接近木头后开始闭合
#         2: GRASPED  - 木头被抬起后一直保持闭合

#     逻辑：
#       - 每个 step 调用一次（EventCfg 里 mode=\"interval\"）
#       - 根据 ee 和 log 的相对位置，更新内部 FSM 状态
#       - 再根据状态，**覆盖 gripper_action 那一段的 action 值**
#     """
#     device = env.device

#     # env_ids 统一成 LongTensor
#     if isinstance(env_ids, slice):
#         env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
#     else:
#         env_ids = env_ids.to(device=device, dtype=torch.long)

#     if env_ids.numel() == 0:
#         return

#     # 取场景里的 robot 和 log 句柄
#     robot = env.scene[robot_asset_cfg.name]
#     log = env.scene[log_asset_cfg.name]

#     # -------------------------------
#     # 1) 初始化 FSM 缓冲（第一次调用时）
#     # -------------------------------
#     if not hasattr(env, "_auto_grasp_state"):
#         # 每个 env 一个状态：0=open, 1=closing, 2=grasped
#         env._auto_grasp_state = torch.zeros(
#             env.num_envs, dtype=torch.int64, device=device
#         )
#         # 记录每个 env 中木头的“初始高度”，之后用来判断是否被抬起
#         env._log_init_height = log.data.root_state_w[:, 2].clone()

#     state_all: torch.Tensor = env._auto_grasp_state        # [num_envs]
#     log_init_h_all: torch.Tensor = env._log_init_height    # [num_envs]

#     state = state_all[env_ids]
#     log_init_h = log_init_h_all[env_ids]

#     # -------------------------------
#     # 2) 在 reset 时重置 FSM
#     # -------------------------------
#     # Isaac Lab 一般有 reset_buf，=1 表示该 env 需要 reset / 刚 reset
#     if hasattr(env, "reset_buf"):
#         reset_mask = env.reset_buf[env_ids] > 0
#         if reset_mask.any():
#             env_ids_reset = env_ids[reset_mask]
#             # 重置状态为 OPEN
#             state_all[env_ids_reset] = 0
#             # 重新记录木头初始高度
#             log_init_h_all[env_ids_reset] = log.data.root_state_w[env_ids_reset, 2]
#             # 更新本地 view
#             state = state_all[env_ids]
#             log_init_h = log_init_h_all[env_ids]

#     # -------------------------------
#     # 3) 计算 EE 与 log 的相对位置
#     # -------------------------------
#     # 末端 link id（我们在 EventCfg 里已写 body_names=["gripper_frame"]）
#     ee_body_ids = robot_asset_cfg.body_ids
#     # body_state_w: [num_envs, num_bodies, 13]
#     ee_state = robot.data.body_state_w[env_ids, ee_body_ids, :]  # [N, 1, 13] 或 [N, 13]
#     if ee_state.ndim == 3:
#         ee_state = ee_state[:, 0, :]  # 只要那一个 body

#     ee_pos = ee_state[:, 0:3]            # [N, 3]

#     # log 的 root_state_w: [num_envs, 13]
#     log_state = log.data.root_state_w[env_ids]   # [N, 13]
#     log_pos = log_state[:, 0:3]                  # [N, 3]

#     # 距离 & 高度
#     dist = torch.linalg.norm(ee_pos - log_pos, dim=-1)  # [N]
#     log_h = log_pos[:, 2]                               # [N]

#     # -------------------------------
#     # 4) FSM 状态转移
#     # -------------------------------
#     is_open = state == 0
#     is_closing = state == 1
#     is_grasped = state == 2

#     # 1) 在 OPEN 状态，如果 EE 靠近 log（小于 close_dist），切到 CLOSING
#     to_closing = is_open & (dist < close_dist)

#     # 2) 在 CLOSING 状态，如果木头被抬起了一定高度，切到 GRASPED
#     to_grasped = is_closing & (log_h > (log_init_h + lift_height))

#     new_state = state.clone()
#     new_state[to_closing] = 1
#     new_state[to_grasped] = 2

#     # 写回全局
#     state_all[env_ids] = new_state

#     # -------------------------------
#     # 5) 找到 gripper_action 在整体 action 向量中的 slice
#     # -------------------------------
#     if not hasattr(env, "_gripper_action_slice"):
#         am = env.action_manager
#         start = 0
#         grip_slice = None
#         for name, dim in zip(am.active_terms, am.action_term_dim):
#             if name == "gripper_action":
#                 grip_slice = slice(start, start + dim)
#                 break
#             start += dim

#         if grip_slice is None:
#             # 没有找到 gripper_action term，就直接退出
#             return

#         env._gripper_action_slice = grip_slice

#     grip_slice = env._gripper_action_slice

#     # ActionManager._action: [num_envs, total_action_dim]
#     # 这里我们直接覆盖掉 gripper_action 对应维度的动作值
#     actions_buf = env.action_manager._action

#     open_mask = new_state == 0
#     closing_mask = new_state == 1
#     grasped_mask = new_state == 2

#     # OPEN 状态：强制张开
#     if open_mask.any():
#         actions_buf[env_ids[open_mask], grip_slice] = open_action

#     # CLOSING / GRASPED 状态：强制闭合
#     closing_or_grasped = closing_mask | grasped_mask
#     if closing_or_grasped.any():
#         actions_buf[env_ids[closing_or_grasped], grip_slice] = close_action
# V 11
# def auto_grasp_log_fsm(
#     env,
#     env_ids,
#     robot_asset_cfg: SceneEntityCfg,
#     log_asset_cfg: SceneEntityCfg,
#     close_dist: float = 0.02,
#     keep_open_xy: float = 0.10,
#     keep_open_z_above: float = 0.02,
#     lift_height: float = 0.15,
#     open_action: float = 1.0,
#     close_action: float = -1.0,
# ):
#     """
#     靠近过程中永远OPEN：
#       - XY 还没对齐到 keep_open_xy 内 -> OPEN
#       - 或 EE 还明显在 log 上方 keep_open_z_above -> OPEN
#     只有真正到位(距离<close_dist)才 CLOSE；抬起后保持 CLOSE
#     """
#     device = env.device

#     # env_ids 兼容 slice/tensor
#     if isinstance(env_ids, slice):
#         env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
#     else:
#         env_ids = env_ids.to(device=device, dtype=torch.long)
#     if env_ids.numel() == 0:
#         return

#     robot = env.scene[robot_asset_cfg.name]
#     log = env.scene[log_asset_cfg.name]

#     ee_body = (robot_asset_cfg.body_names[0] if getattr(robot_asset_cfg, "body_names", None) else "gripper_frame")
#     body_ids, _ = robot.find_bodies([ee_body])
#     ee_idx = int(body_ids[0])

#     ee_pos_w  = robot.data.body_state_w[env_ids, ee_idx, 0:3]     # (M,3)
#     log_pos_w = log.data.root_state_w[env_ids, 0:3]               # (M,3)

#     d = ee_pos_w - log_pos_w
#     d_xy = torch.linalg.norm(d[:, 0:2], dim=1)
#     dist = torch.linalg.norm(d, dim=1)

#     # 还在靠近 -> 强制张开
#     approaching = (d_xy > keep_open_xy) | (d[:, 2] > keep_open_z_above)

#     # 到位才闭合
#     ready_to_close = (~approaching) & (dist < close_dist)

#     # 抬起后保持闭合（用 log 高度判定）
#     lifted = (log_pos_w[:, 2] > lift_height)

#     # 输出每个 env 一个动作值
#     grip = torch.full((env_ids.numel(),), float(open_action), device=device)
#     grip[ready_to_close | lifted] = float(close_action)

#     # ✅ 如果你的旧实现是“返回动作让系统覆盖”，就返回
#     return grip

import torch
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import matrix_from_quat

@torch.no_grad()
def auto_grasp_log_fsm(
    env,
    env_ids,
    robot_asset_cfg: SceneEntityCfg,
    log_asset_cfg: SceneEntityCfg,
    close_dist: float = 0.05,
    keep_open_xy: float = 0.06,
    keep_open_z_above: float = 0.01,
    lift_height: float = 0.15,
    open_action: float = 1.0,
    close_action: float = -1.0,
    hold_steps: int = 8,

    # ✅ 新增：抬起控制（覆盖 arm_action）
    lift_action: float = 1.0,      # 对应 dz 的动作值（乘你的 scale=0.01）
    hold_arm_zero: bool = True,    # close 时把 arm action 置 0，避免继续推
):
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    robot = env.scene[robot_asset_cfg.name]
    log   = env.scene[log_asset_cfg.name]

    # ---------------------------
    # init buffers
    # ---------------------------
    if not hasattr(env, "_grasp_phase"):
        env._grasp_phase = torch.zeros(env.num_envs, dtype=torch.long, device=device)    # 0/1/2
        env._hold_counter = torch.zeros(env.num_envs, dtype=torch.long, device=device)
        env._log_z0 = log.data.root_state_w[:, 2].clone()

    # reset handling
    if hasattr(env, "reset_buf"):
        r = env.reset_buf > 0
        if r.any():
            env._grasp_phase[r] = 0
            env._hold_counter[r] = 0
            env._log_z0[r] = log.data.root_state_w[r, 2]

    # EE pos (用 gripper_frame 或你传进来的 body_names[0])
    ee_body = (robot_asset_cfg.body_names[0] if getattr(robot_asset_cfg, "body_names", None) else "gripper_frame")
    body_ids, _ = robot.find_bodies([ee_body])
    if len(body_ids) == 0:
        return
    ee_idx = int(body_ids[0])

    ee_pos_w  = robot.data.body_state_w[env_ids, ee_idx, 0:3]
    log_pos_w = log.data.root_state_w[env_ids, 0:3]

    d = ee_pos_w - log_pos_w
    d_xy = torch.linalg.norm(d[:, 0:2], dim=1)
    dist = torch.linalg.norm(d, dim=1)

    phase = env._grasp_phase[env_ids]

    approaching = (d_xy > keep_open_xy) | (d[:, 2] > keep_open_z_above)
    ready_to_close = (~approaching) & (dist < close_dist)

    # phase0 -> phase1
    to_p1 = (phase == 0) & ready_to_close
    if to_p1.any():
        ids = env_ids[to_p1]
        env._grasp_phase[ids] = 1
        env._hold_counter[ids] = 0

    # phase1 hold -> phase2
    phase = env._grasp_phase[env_ids]
    p1 = (phase == 1)
    if p1.any():
        ids = env_ids[p1]
        env._hold_counter[ids] += 1
        to_p2 = env._hold_counter[ids] >= int(hold_steps)
        if to_p2.any():
            env._grasp_phase[ids[to_p2]] = 2

    # lifted detection (保险)
    phase = env._grasp_phase[env_ids]
    lifted = (log_pos_w[:, 2] > (env._log_z0[env_ids] + lift_height))
    if lifted.any():
        env._grasp_phase[env_ids[lifted]] = 2

    # ---------------------------
    # 1) override gripper_action
    # ---------------------------
    phase = env._grasp_phase[env_ids]
    grip = torch.full((env_ids.numel(),), float(open_action), device=device)
    grip[phase >= 1] = float(close_action)

    if not hasattr(env, "_gripper_action_slice"):
        am = env.action_manager
        start = 0
        s = None
        for name, dim in zip(am.active_terms, am.action_term_dim):
            if name == "gripper_action":
                s = slice(start, start + dim)
                break
            start += dim
        if s is None:
            raise RuntimeError("Cannot find 'gripper_action' in action_manager.")
        env._gripper_action_slice = s

    env.action_manager._action[env_ids, env._gripper_action_slice] = grip.unsqueeze(-1)  # (N,1)

    # ---------------------------
    # 2) ✅ override arm_action (关键：让爪子真的抬起来)
    # ---------------------------
    if not hasattr(env, "_arm_action_slice"):
        am = env.action_manager
        start = 0
        s = None
        for name, dim in zip(am.active_terms, am.action_term_dim):
            if name == "arm_action":
                s = slice(start, start + dim)
                break
            start += dim
        if s is None:
            raise RuntimeError("Cannot find 'arm_action' in action_manager.")
        env._arm_action_slice = s

    arm_slice = env._arm_action_slice

    # arm_action 期望是 (dx,dy,dz) —— 你用的是 command_type="position"
    arm = torch.zeros((env_ids.numel(), 3), device=device)

    # phase>=1：避免继续推（可选）
    if hold_arm_zero:
        arm[phase >= 1, :] = 0.0

    # phase==2：强制 dz 向上
    arm[phase == 2, 2] = float(lift_action)

    env.action_manager._action[env_ids, arm_slice] = arm

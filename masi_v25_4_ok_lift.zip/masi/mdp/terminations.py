# Copyright (c) 2024-2025, Muammer Bay (LycheeAI), Louis Le Lay
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause
#
# Copyright (c) 2022-2025, The Isaac Lab Project Developers.
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause


# jack add  28.10.2025 


"""Common functions that can be used to activate certain terminations for the lift task.

The functions can be passed to the :class:`isaaclab.managers.TerminationTermCfg` object to enable
the termination introduced by the function.
"""

from __future__ import annotations  
from typing import TYPE_CHECKING

import torch
from isaaclab.assets import RigidObject
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import combine_frame_transforms

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedRLEnv


def object_reached_goal(
    env: ManagerBasedRLEnv,
    command_name: str = "object_pose",
    threshold: float = 0.02,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    object_cfg: SceneEntityCfg = SceneEntityCfg("object"),
) -> torch.Tensor:
    """Termination condition for the object reaching the goal position.

    Args:
        env: The environment.
        command_name: The name of the command that is used to control the object.
        threshold: The threshold for the object to reach the goal position. Defaults to 0.02.
        robot_cfg: The robot configuration. Defaults to SceneEntityCfg("robot").
        object_cfg: The object configuration. Defaults to SceneEntityCfg("object").

    """
    # extract the used quantities (to enable type-hinting)
    robot: RigidObject = env.scene[robot_cfg.name]
    object: RigidObject = env.scene[object_cfg.name]
    command = env.command_manager.get_command(command_name)
    # compute the desired position in the world frame
    des_pos_b = command[:, :3]
    des_pos_w, _ = combine_frame_transforms(robot.data.root_state_w[:, :3], robot.data.root_state_w[:, 3:7], des_pos_b)
    # distance of the end-effector to the object: (num_envs,)
    distance = torch.norm(des_pos_w - object.data.root_pos_w[:, :3], dim=1)

    # rewarded if the object is lifted above the threshold
    return distance < threshold
# ---- 放在本文件顶部 import 之后（mdp 导入下面也行）----

def root_position_out_of_bounds(env, asset_cfg=SceneEntityCfg("robot"),
                                bounds=None):
    """
    若机器人根在 env 局部坐标下越界，返回 True 的 done 掩码。
    bounds: {"x":(min,max), "y":(min,max), "z":(min,max)}
    """
    if bounds is None:
        bounds = {"x": (-2.0, 2.0), "y": (-2.0, 2.0), "z": (-1.0, 2.0)}
    actor = env.scene[asset_cfg.name]
    origins = env.scene.env_origins                             # [N,3]
    pos_local = actor.data.root_pos_w[:, :3] - origins          # [N,3]

    low  = torch.tensor([bounds["x"][0], bounds["y"][0], bounds["z"][0]],
                        device=pos_local.device)
    high = torch.tensor([bounds["x"][1], bounds["y"][1], bounds["z"][1]],
                        device=pos_local.device)

    too_low  = (pos_local < low).any(dim=1)
    too_high = (pos_local > high).any(dim=1)
    return (too_low | too_high)                                 # torch.bool[N]


def ee_speed_above_limit(env, asset_cfg=SceneEntityCfg("robot"),
                         ee_body_name="gripper_frame", limit_lin=8.0, limit_ang=40.0):
    """
    末端刚体线/角速度超过阈值则终止（单位：m/s, rad/s），
    可作为“保险丝”，防止一步速度爆表把物体推飞。
    """
    robot = env.scene[asset_cfg.name]
    # 缓存 body id
    key = "_ee_body_id_for_speed_oob"
    if not hasattr(env, key):
        body_ids, _ = robot.find_bodies([ee_body_name])
        if len(body_ids) != 1:
            raise RuntimeError(f"EE body '{ee_body_name}' not found")
        setattr(env, key, int(body_ids[0]))
    b = getattr(env, key)

    vel = robot.data.body_lin_vel_w[:, b, :]     # [N,3]
    ang = robot.data.body_ang_vel_w[:, b, :]     # [N,3]
    over_lin = torch.linalg.norm(vel, dim=1) > limit_lin
    over_ang = torch.linalg.norm(ang, dim=1) > limit_ang
    return (over_lin | over_ang)                 # torch.bool[N]


def any_body_pos_out_of_bounds(env, asset_cfg=SceneEntityCfg("robot"), bound=0.8):
    """
    任一刚体在 env-local 坐标下 |pos| 超过 bound(m) 则终止该 env。
    收紧到 0.8m，避免‘视觉炸姿态’持续刷屏。
    """
    actor = env.scene[asset_cfg.name]
    origins = env.scene.env_origins  # [N,3]
    pos_w = actor.data.body_state_w[:, :, :3]            # [N,B,3]
    pos_local = pos_w - origins.unsqueeze(1)             # [N,B,3]
    over = (pos_local.abs() > bound).any(dim=2).any(dim=1)  # [N]
    return over

def any_body_speed_oob(env, asset_cfg=SceneEntityCfg("robot"),
                       limit_lin=8.0, limit_ang=40.0):
    """
    任一刚体线/角速度超过阈值则终止（单位：m/s, rad/s）。
    """
    actor = env.scene[asset_cfg.name]
    lin = actor.data.body_lin_vel_w    # [N,B,3]
    ang = actor.data.body_ang_vel_w    # [N,B,3]
    over_lin = torch.linalg.norm(lin, dim=2) > limit_lin  # [N,B]
    over_ang = torch.linalg.norm(ang, dim=2) > limit_ang
    return (over_lin | over_ang).any(dim=1)              # [N]

def has_nan_or_inf(env, asset_cfg=SceneEntityCfg("robot")):
    """
    任一刚体的状态出现 NaN/Inf 时终止（保险丝）。
    """
    actor = env.scene[asset_cfg.name]
    state = actor.data.body_state_w  # [N,B,13]
    bad = torch.isnan(state).any(dim=(1,2)) | torch.isinf(state).any(dim=(1,2))
    return bad

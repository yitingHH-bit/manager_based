from __future__ import annotations
import math
import torch
from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import (
    subtract_frame_transforms,
    quat_from_angle_axis,
    quat_mul,
    matrix_from_quat,
    quat_from_euler_xyz,
    quat_slerp,
)

# ----------------------------------------------------------
# 辅助函数
# ----------------------------------------------------------
def _yaw_from_quat_wxyz(q: torch.Tensor) -> torch.Tensor:
    """从四元数计算 yaw 角"""
    w, x, y, z = q.unbind(-1)
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    return torch.atan2(siny_cosp, cosy_cosp)


def _wrap_to_pi(a: torch.Tensor) -> torch.Tensor:
    """限制角度到 [-pi, pi]"""
    return (a + math.pi) % (2.0 * math.pi) - math.pi


def _clamp_step(vec: torch.Tensor, max_step: float) -> torch.Tensor:
    """对 3D 向量做每步最大位移裁剪"""
    n = torch.linalg.norm(vec, dim=-1, keepdim=True).clamp_min(1e-9)
    scale = torch.clamp(torch.tensor(max_step, device=vec.device, dtype=vec.dtype) / n, max=1.0)
    return vec * scale


import torch
from isaaclab.envs import ManagerBasedRLEnv


@torch.no_grad()
def reset_sync_ee_pose_state(env: ManagerBasedRLEnv, env_ids: torch.Tensor):
    """Reset internal buffers used by sync_ee_pose_to_log_*."""
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    if hasattr(env, "_log_prev_pos"):
        env._log_prev_pos[env_ids] = 0.0
    if hasattr(env, "_log_stable_counter"):
        env._log_stable_counter[env_ids] = 0

@torch.no_grad()
def sync_ee_pose_to_log_two_stage_position_only(
    env: ManagerBasedRLEnv,
    env_ids: torch.Tensor,
    command_name: str,
    robot_asset_cfg,
    log_asset_cfg,
    approach_height: float = 0.10,
    descend_xy: float = 0.06,
    final_z_offset: float = 0.0,
    log_half_height: float = 0.02,
    snap_dist: float = 0.25,
    max_pos_step: float = 0.02,
    move_threshold: float = 0.02,
    cooldown_steps: int = 3,
    blend: float = 0.2,
    lift_z: float = 0.12,
):
    """Track log target using *position only* command.
    - stage0: hover above log top (approach_height)
    - stage1: descend when XY close (descend_xy)
    - if env._grasp_phase >= 1: lock XY using env._lock_xy
    - if env._grasp_phase == 2: lock z0 and add lift_z
    Notes:
    - We do NOT overwrite quaternion (orientation) to avoid coordinate confusion.
    """
    device = env.device
    robot = env.scene[robot_asset_cfg.name]
    log = env.scene[log_asset_cfg.name]

    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    # log movement filtering (avoid chasing pushed log too aggressively)
    if not hasattr(env, "_log_prev_pos"):
        env._log_prev_pos = torch.zeros_like(log.data.root_pos_w)
        env._log_stable_counter = torch.zeros(env.num_envs, dtype=torch.long, device=device)

    log_pos_cur = log.data.root_pos_w[:, :3]
    moved = torch.linalg.norm(log_pos_cur - env._log_prev_pos[:, :3], dim=1) > float(move_threshold)
    env._log_stable_counter[moved] = 0
    env._log_stable_counter += 1
    env._log_prev_pos[:, :3] = log_pos_cur

    valid_mask = env._log_stable_counter >= int(cooldown_steps)

    # once grasping starts, do not block by cooldown
    if hasattr(env, "_grasp_phase"):
        valid_mask = valid_mask | (env._grasp_phase >= 1)

    valid_envs = env_ids[valid_mask[env_ids]]
    if valid_envs.numel() == 0:
        return

    # desired position in base-translation frame
    base_pos_w = robot.data.root_state_w[valid_envs, 0:3]
    log_top_w = log.data.root_pos_w[valid_envs, :3].clone()
    log_top_w[:, 2] += float(log_half_height)

    des_pos_b = log_top_w - base_pos_w
    des_pos_b[:, 2] += float(final_z_offset)

    cmd = env.command_manager.get_command(command_name)
    cur_pos_b = cmd[valid_envs, 0:3].clone()

    # two-stage hover/descend
    delta_xy = des_pos_b[:, 0:2] - cur_pos_b[:, 0:2]
    dist_xy = torch.linalg.norm(delta_xy, dim=1)

    hover_pos_b = des_pos_b.clone()
    hover_pos_b[:, 2] += float(approach_height)

    target_pos_b = torch.where(
        (dist_xy > float(descend_xy)).unsqueeze(1),
        hover_pos_b,
        des_pos_b,
    )

    # FSM overrides
    if hasattr(env, "_grasp_phase"):
        phase = env._grasp_phase[valid_envs]
        if hasattr(env, "_lock_xy"):
            hold = phase >= 1
            if hold.any():
                target_pos_b[hold, 0:2] = env._lock_xy[valid_envs[hold]]
        if hasattr(env, "_lock_z0"):
            lift = phase == 2
            if lift.any():
                target_pos_b[lift, 2] = env._lock_z0[valid_envs[lift]] + float(lift_z)

    # snap + step limit
    delta = target_pos_b - cur_pos_b
    dist = torch.linalg.norm(delta, dim=1)

    far = dist > float(snap_dist)
    if far.any():
        cur_pos_b[far] = target_pos_b[far]

    near = ~far
    if near.any():
        step = delta[near]
        step_len = torch.linalg.norm(step, dim=1, keepdim=True).clamp(min=1e-8)
        step = step * torch.clamp(float(max_pos_step) / step_len, max=1.0)
        cur_pos_b[near] += step

    new_pos_b = cur_pos_b
    prev_pos = cmd[valid_envs, 0:3]
    blended_pos = prev_pos * (1.0 - float(blend)) + new_pos_b * float(blend)

    # write back (orientation untouched)
    cmd[valid_envs, 0:3] = blended_pos

 

#  v15
import torch
from isaaclab.utils.math import quat_from_euler_xyz, quat_mul, matrix_from_quat

@torch.no_grad()
def sync_ee_pose_to_log_upright_yaw_two_stage(
    env,
    env_ids: torch.Tensor,
    command_name: str,
    robot_asset_cfg,
    log_asset_cfg,
    approach_height: float = 0.10,
    descend_xy: float = 0.06,
    final_z_offset: float = 0.0,
    yaw_offset: float = 0.0,
    upright_base_quat_wxyz=(1.0, 0.0, 0.0, 0.0),
    # ✅ 用真实 EE tip（和你抓取判断一致）
    ee_body_name: str = "ee",     # 或 "ee"（看你实际用哪个）
    ee_offset_local=(0.0, 0.0, 0.0),       # tip offset（和你抓取逻辑对齐）
    # 平滑/限幅
    snap_dist: float = 0.20,
    max_pos_step: float = 0.03,
    blend: float = 0.2,
    # ✅ log 抖动滤波（0.0=不用，0.1~0.2 常用）
    log_ema: float = 0.15,
    # ✅ lift（phase==2 时）
    lift_z: float = 0.18,
):
    device = env.device
    robot = env.scene[robot_asset_cfg.name]
    log   = env.scene[log_asset_cfg.name]

    # env_ids 兼容 slice
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    # ----------------------------
    # 1) 取 log 位置（加 EMA 减抖）
    # ----------------------------
    log_pos_raw = log.data.root_pos_w[:, :3]
    if (log_ema is not None) and (log_ema > 0.0):
        if not hasattr(env, "_log_pos_filt"):
            env._log_pos_filt = log_pos_raw.clone()
        env._log_pos_filt[env_ids] = (1.0 - log_ema) * env._log_pos_filt[env_ids] + log_ema * log_pos_raw[env_ids]
        log_pos_w_all = env._log_pos_filt
    else:
        log_pos_w_all = log_pos_raw

    valid_envs = env_ids  # 这里先不做 cooldown 卡住（否则又会莫名不更新）

    log_pos_w  = log_pos_w_all[valid_envs]
    base_pos_w = robot.data.root_state_w[valid_envs, 0:3]

    # 目标（base translation frame）
    des_pos_b = log_pos_w - base_pos_w
    des_pos_b[:, 2] += float(final_z_offset)

    # ----------------------------
    # 2) 用真实 EE tip 判断是否允许 descend
    # ----------------------------
    body_ids, _ = robot.find_bodies([ee_body_name])
    if len(body_ids) == 0:
        return
    ee_idx = int(body_ids[0])

    ee_p_w = robot.data.body_state_w[valid_envs, ee_idx, 0:3]
    ee_q_w = robot.data.body_state_w[valid_envs, ee_idx, 3:7]  # wxyz

    R = matrix_from_quat(ee_q_w)
    off = torch.as_tensor(ee_offset_local, device=device, dtype=ee_p_w.dtype).view(1, 3, 1)
    ee_tip_w = ee_p_w + (R @ off).squeeze(-1)
    ee_tip_b = ee_tip_w - base_pos_w  # translation only

    # ✅ 关键：用 EE 到 log 的 XY 距离决定 descend（不是用 command）
    delta_xy_ee = des_pos_b[:, 0:2] - ee_tip_b[:, 0:2]
    dist_xy_ee = torch.linalg.norm(delta_xy_ee, dim=1)

    hover_pos_b = des_pos_b.clone()
    hover_pos_b[:, 2] += float(approach_height)

    target_pos_b = torch.where(
        (dist_xy_ee > float(descend_xy)).unsqueeze(1),
        hover_pos_b,
        des_pos_b,
    )

    # ----------------------------
    # 3) phase override：close/lift 锁 XY，lift 抬 Z
    # ----------------------------
    if hasattr(env, "_grasp_phase") and hasattr(env, "_lock_xy"):
        phase = env._grasp_phase[valid_envs]  # (K,)

        mask_hold = phase >= 1
        if mask_hold.any():
            lock_xy_w = env._lock_xy[valid_envs[mask_hold]]          # (M,2) world
            lock_xy_b = lock_xy_w - base_pos_w[mask_hold, 0:2]       # -> base frame
            target_pos_b[mask_hold, 0:2] = lock_xy_b

        mask_lift = phase == 2
        if mask_lift.any():
            target_pos_b[mask_lift, 2] = des_pos_b[mask_lift, 2] + float(lift_z)

    # ----------------------------
    # 4) 写回 command（snap + step limit + blend）
    # ----------------------------
    cmd = env.command_manager.get_command(command_name)
    cur_pos_b = cmd[valid_envs, 0:3]

    delta = target_pos_b - cur_pos_b
    dist  = torch.linalg.norm(delta, dim=1)

    far_mask = dist > float(snap_dist)
    if far_mask.any():
        cur_pos_b[far_mask] = target_pos_b[far_mask]

    near_mask = ~far_mask
    if near_mask.any():
        step = delta[near_mask]
        step_len = torch.linalg.norm(step, dim=1, keepdim=True).clamp(min=1e-8)
        step = step * torch.clamp(float(max_pos_step) / step_len, max=1.0)
        cur_pos_b[near_mask] += step

    new_pos_b = cur_pos_b

    # 姿态：竖直 + yaw_offset
    upright_quat = torch.tensor(upright_base_quat_wxyz, device=device, dtype=torch.float32).repeat(len(valid_envs), 1)
    roll  = torch.zeros(len(valid_envs), 1, device=device)
    pitch = torch.zeros(len(valid_envs), 1, device=device)
    yaw   = torch.full((len(valid_envs), 1), float(yaw_offset), device=device)
    yaw_quat = quat_from_euler_xyz(roll, pitch, yaw).view(len(valid_envs), 4)
    new_quat_b = quat_mul(upright_quat, yaw_quat)

    prev_pos  = cmd[valid_envs, 0:3]
    prev_quat = cmd[valid_envs, 3:7]

    blended_pos = prev_pos * (1 - blend) + new_pos_b * blend

    dot = torch.sum(prev_quat * new_quat_b, dim=1, keepdim=True).clamp(-1.0, 1.0)
    theta = torch.acos(dot) * blend
    rel = torch.nn.functional.normalize(new_quat_b - prev_quat * dot, dim=1)
    blended_quat = torch.nn.functional.normalize(prev_quat * torch.cos(theta) + rel * torch.sin(theta), dim=1)

    cmd[valid_envs, 0:3] = blended_pos
    # cmd[valid_envs, 3:7] = blended_quat  # keep orientation (do not force)
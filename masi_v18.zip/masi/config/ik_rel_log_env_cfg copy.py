from dataclasses import MISSING
import math

import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg, AssetBaseCfg, RigidObjectCfg
from isaaclab.controllers.differential_ik_cfg import DifferentialIKControllerCfg
from isaaclab.envs import ManagerBasedRLEnvCfg
from isaaclab.envs.mdp.actions.actions_cfg import DifferentialInverseKinematicsActionCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.utils import configclass
from isaaclab.utils.noise import AdditiveUniformNoiseCfg as Unoise

# Isaac Lab 自带 reach 任务里的 MDP 实现（用于 position_command_error 等）
import isaaclab_tasks.manager_based.manipulation.reach.mdp as mdp_isaac

# 你的 excavator 机器人配置
from isaaclab_assets.robots.masiV0 import MASI_CFG

# 你自定义的 MDP 函数（joint_pos_rel, ee_to_log_distance, 等）
from .. import mdp


# -----------------------------------------------------------------------------
# 场景配置：MASI + 木头 log
# -----------------------------------------------------------------------------
@configclass
class MasiLogSceneCfg(InteractiveSceneCfg):
    """Scene with MASI and a simple log object to reach."""

    # 机器人
    robot: ArticulationCfg = MISSING

    # 木头：作为被操作的对象
    log: RigidObjectCfg = RigidObjectCfg(
        prim_path="{ENV_REGEX_NS}/Log",
        spawn=sim_utils.CuboidCfg(
            size=(0.06, 0.20, 0.06),
            rigid_props=sim_utils.RigidBodyPropertiesCfg(
                max_linear_velocity=10.0,
                max_angular_velocity=30.0,
            ),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.100),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.1, 0.0)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(0.6, 0.0, 0.03),
            rot=(1.0, 0.0, 0.0, 0.0),
        ),
    )

    # 地面
    plane = AssetBaseCfg(
        prim_path="/World/GroundPlane",
        init_state=AssetBaseCfg.InitialStateCfg(),
        spawn=sim_utils.GroundPlaneCfg(),
    )

    # 光照
    light = AssetBaseCfg(
        prim_path="/World/Light",
        spawn=sim_utils.DomeLightCfg(intensity=3000.0, color=(0.75, 0.75, 0.75)),
    )


# -----------------------------------------------------------------------------
# Observation：让策略看到自身状态 + 目标 ee_pose + log 方向 + 上一步动作
# -----------------------------------------------------------------------------
@configclass
class ObservationsCfg:

    @configclass
    class PolicyCfg(ObsGroup):
        """Observations for the policy."""

        # 1) 机器人自身状态
        joint_pos = ObsTerm(
            func=mdp.joint_pos_rel,
            noise=Unoise(n_min=-0.01, n_max=0.01),
        )
        joint_vel = ObsTerm(
            func=mdp.joint_vel_rel,
            noise=Unoise(n_min=-0.01, n_max=0.01),
        )

        # 2) 目标末端位姿命令：ee_pose（由 CommandsCfg 生成）
        pose_command_ee = ObsTerm(
            func=mdp.generated_commands,
            params={"command_name": "ee_pose"},
        )

        # 3) log 在 base 坐标系下的方向（帮助 cabin yaw 对齐）
        log_dir = ObsTerm(
            func=mdp.log_dir_in_base,
        )

        # 4) 上一步动作
        actions = ObsTerm(
            func=mdp.last_action,
        )

        def __post_init__(self):
            # 可以先关掉观测扰动，训练稳定后再打开
            self.enable_corruption = False
            self.concatenate_terms = True

    # observation group
    policy: PolicyCfg = PolicyCfg()


# -----------------------------------------------------------------------------
# 动作：Differential IK 控制 excavator 末端 + 二值 gripper
# -----------------------------------------------------------------------------
@configclass
class ActionsCfg:
    """Action specifications for the MDP."""

    # 机械臂 IK 动作
    arm_action = DifferentialInverseKinematicsActionCfg(
        asset_name="robot",
        joint_names=[
            "revolute_cabin",
            "revolute_lift",
            "revolute_tilt",
            "revolute_scoop",
            "revolute_gripper",
        ],
        body_name="gripper_frame",  # IK 末端
        controller=DifferentialIKControllerCfg(
            command_type="pose",
            use_relative_mode=True,
            ik_method="dls",
            ik_params={"lambda_val": 0.08},
        ),
        scale=0.0025,
        body_offset=DifferentialInverseKinematicsActionCfg.OffsetCfg(
            pos=[0.0, 0.0, 0.0],  # 如需补偿爪子长度，可后面改为 [0, 0, -0.08] 等
        ),
    )

    # 爪子二值开合
    gripper_action = mdp.BinaryJointPositionActionCfg(
        asset_name="robot",
        joint_names=["revolute_claw_1", "revolute_claw_2"],
        open_command_expr={
            "revolute_claw_1": +0.20,
            "revolute_claw_2": -0.20,  # 如果实际两边同向，则都写 +0.20
        },
        close_command_expr={
            "revolute_claw_1": 0.0,
            "revolute_claw_2": 0.0,
        },
    )


# -----------------------------------------------------------------------------
# 事件：重置关节
# -----------------------------------------------------------------------------
@configclass
class EventCfg:
    """Configuration for events."""

    reset_robot_joints = EventTerm(
        func=mdp.reset_joints_by_scale,
        mode="reset",
        params={
            "position_range": (0.5, 1.5),
            "velocity_range": (0.0, 0.0),
        },
    )


# -----------------------------------------------------------------------------
# Commands：生成“木头上的接触点”作为末端位姿命令 ee_pose
# -----------------------------------------------------------------------------
@configclass
class CommandsCfg:
    """
    末端位姿命令：
    - asset_name="log"：以木头为参考物体
    - body_name="Log"：对应 MasiLogSceneCfg 里 log 的刚体
    - ranges 是在 log 局部坐标系下的小范围偏移，相当于“木头上方 8~12cm 的点”
    """

    ee_pose = mdp.UniformPoseCommandCfg(
        asset_name="log",
        body_name="Log",
        resampling_time_range=(9999.0, 9999.0),  # 一整个 episode 只采样一次目标点
        debug_vis=True,
        ranges=mdp.UniformPoseCommandCfg.Ranges(
            pos_x=(-0.02, 0.02),
            pos_y=(-0.02, 0.02),
            pos_z=(0.08, 0.12),  # 在木头表面上方一点，给爪子留空间
            roll=(0.0, 0.0),
            pitch=(0.0, 0.0),
            yaw=(0.0, 0.0),
        ),
    )


# -----------------------------------------------------------------------------
# Terminations：时间/越界/速度/NaN 等安全终止
# -----------------------------------------------------------------------------
@configclass
class TerminationsCfg:
    """Termination terms for the MDP."""

    # episode 时间到
    time_out = DoneTerm(
        func=mdp.time_out,
        time_out=True,
    )

    # 机器人根链接位置越界
    root_oob = DoneTerm(
        func=mdp.root_position_out_of_bounds,
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "bounds": {"x": (-3.0, 3.0), "y": (-3.0, 3.0), "z": (-1.0, 3.0)},
        },
    )

    # 末端速度过大
    ee_speed_oob = DoneTerm(
        func=mdp.ee_speed_above_limit,
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "ee_body_name": "gripper_frame",
            "limit_lin": 0.8,
            "limit_ang": 6.0,
        },
    )

    # 任意刚体速度过大
    any_link_speed_oob = DoneTerm(
        func=mdp.any_body_speed_oob,
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "limit_lin": 0.8,
            "limit_ang": 6.0,
        },
    )

    # 任意刚体位置越界
    any_link_oob = DoneTerm(
        func=mdp.any_body_pos_out_of_bounds,
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "bound": 2.5,
        },
    )

    # NaN / Inf 保护
    nan_inf_guard = DoneTerm(
        func=mdp.has_nan_or_inf,
        params={"asset_cfg": SceneEntityCfg("robot")},
    )


# -----------------------------------------------------------------------------
# Rewards：以 EE 跟踪 ee_pose 为主，log 相关为辅助 shaping
# -----------------------------------------------------------------------------
@configclass
class RewardsCfg:
    """Reward terms for the excavator reach-log task."""

    # 1) 末端位置 tracking：L2 误差（惩罚项）
    end_effector_position_tracking = RewTerm(
        func=mdp_isaac.position_command_error,
        weight=-0.5,
        params={
            "asset_cfg": SceneEntityCfg("robot", body_names=["gripper_frame"]),
            "command_name": "ee_pose",
        },
    )

    # 2) 末端位置 tracking：tanh 细粒度 shaping（奖励项）
    end_effector_position_tracking_fine_grained = RewTerm(
        func=mdp_isaac.position_command_error_tanh,
        weight=1.0,
        params={
            "asset_cfg": SceneEntityCfg("robot", body_names=["gripper_frame"]),
            "std": 0.15,
            "command_name": "ee_pose",
        },
    )

    # 3) （轻量）EE 靠近 log 的 shaping
    reaching_log = RewTerm(
        func=mdp.ee_to_log_distance,
        weight=0.5,
    )

    # 4) cabin yaw 对齐 log 方向的 shaping
    cabin_yaw_align = RewTerm(
        func=mdp.cabin_yaw_aligns_target,
        weight=0.5,
        params={"eps": 1e-3},
    )

    # 5) 动作平滑惩罚，防止抖动
    action_rate = RewTerm(
        func=mdp.safe_action_rate_l2,
        weight=-0.001,
    )


# -----------------------------------------------------------------------------
# 环境配置
# -----------------------------------------------------------------------------
@configclass
class MasiIkReachLogEnvCfg(ManagerBasedRLEnvCfg):
    """Configuration for the MASI excavator log reaching environment."""

    # 场景
    scene: MasiLogSceneCfg = MasiLogSceneCfg(
        num_envs=1024,
        env_spacing=2.5,
    )

    # MDP 相关配置
    observations: ObservationsCfg = ObservationsCfg()
    actions: ActionsCfg = ActionsCfg()
    rewards: RewardsCfg = RewardsCfg()
    terminations: TerminationsCfg = TerminationsCfg()
    events: EventCfg = EventCfg()
    commands: CommandsCfg = CommandsCfg()

    def __post_init__(self):
        super().__post_init__()

        # 绑定 excavator 机器人
        self.scene.robot = MASI_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot")
        self.scene.robot.init_state.pos = (0.0, 0.0, 0.12)
        self.scene.robot.init_state.rot = (1.0, 0.0, 0.0, 0.0)

        # 仿真与 RL 步长设置
        self.sim.dt = 1.0 / 60.0
        self.decimation = 2          # RL 每 2 个 sim step 一次
        self.episode_length_s = 12.0
        self.sim.render_interval = self.decimation


@configclass
class MasiIkReachLogEnvCfg_PLAY(MasiIkReachLogEnvCfg):
    """小规模可视化用配置（用于 play / debug）"""

    def __post_init__(self):
        super().__post_init__()
        self.scene.num_envs = 32
        self.scene.env_spacing = 2.5
        self.observations.policy.enable_corruption = False

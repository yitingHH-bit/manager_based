from dataclasses import MISSING
import math

import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg, AssetBaseCfg, RigidObjectCfg
from isaaclab.controllers.differential_ik_cfg import DifferentialIKControllerCfg
from isaaclab.envs import ManagerBasedRLEnvCfg
from isaaclab.envs.mdp.actions.actions_cfg import DifferentialInverseKinematicsActionCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.utils import configclass
from isaaclab.utils.noise import AdditiveUniformNoiseCfg as Unoise

import isaaclab_tasks.manager_based.manipulation.reach.mdp as mdp_isaac
from isaaclab_assets.robots.masiV0 import MASI_CFG
from .. import mdp

# -------------------------------------------------------------------------
# ✅ EE 定义：以 gripper_frame（夹爪关节根部）为 EE body
#    TIP_OFFSET_LOCAL 用于 tip 计算（抓取判定 / descend 判定），先按 -Z
# -------------------------------------------------------------------------
EE_BODY = "gripper_frame"
TIP_OFFSET_LOCAL = (-0.0385, 0.0, 0.0)   # 来自 URDF 里 claw fixed joint 的 z=-0.03853
TCP_OFFSET_LOCAL = (-0.0385, 0.0, 0.0)
# IK 追踪 EE_BODY 本身（关节位置），所以 offset=0
IK_BODY_OFFSET = (0.0, 0.0, 0.0)

LOG_HALF_HEIGHT = 0.02  # log size 0.04

# ✅ 调整upright姿态，让EE“指下”
UPRIGHT_QUAT_WXYZ = (0.707, 0.707, 0.0, 0.0)

@configclass
class MasiLogSceneCfg(InteractiveSceneCfg):
    """Scene with MASI + a simple log object to reach."""
    robot: ArticulationCfg = MISSING

    log: RigidObjectCfg = RigidObjectCfg(
        prim_path="{ENV_REGEX_NS}/Log",
        spawn=sim_utils.CuboidCfg(
            size=(0.04, 0.04, 0.04),
            rigid_props=sim_utils.RigidBodyPropertiesCfg(
                max_linear_velocity=10.0,
                max_angular_velocity=30.0,
            ),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.100),
            physics_material=sim_utils.RigidBodyMaterialCfg(
                static_friction=1.5,
                dynamic_friction=1.5,
                restitution=0.0,
            ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.1, 0.0)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(0.7, 0.0, 0.03),
            rot=(1.0, 0.0, 0.0, 0.0),
        ),
    )

    plane = AssetBaseCfg(
        prim_path="/World/GroundPlane",
        init_state=AssetBaseCfg.InitialStateCfg(),
        spawn=sim_utils.GroundPlaneCfg(),
    )

    light = AssetBaseCfg(
        prim_path="/World/Light",
        spawn=sim_utils.DomeLightCfg(intensity=3000.0, color=(0.75, 0.75, 0.75)),
    )


@configclass
class ObservationsCfg:
    @configclass
    class PolicyCfg(ObsGroup):
        joint_pos = ObsTerm(func=mdp.joint_pos_rel, noise=Unoise(n_min=-0.01, n_max=0.01))
        joint_vel = ObsTerm(func=mdp.joint_vel_rel, noise=Unoise(n_min=-0.01, n_max=0.01))

        pose_command_ee = ObsTerm(func=mdp.generated_commands, params={"command_name": "ee_pose"})

        log_dir = ObsTerm(func=mdp.log_dir_in_base)
        actions = ObsTerm(func=mdp.last_action)

        def __post_init__(self):
            self.enable_corruption = False
            self.concatenate_terms = True

    policy: PolicyCfg = PolicyCfg()


@configclass
class ActionsCfg:
    arm_action = DifferentialInverseKinematicsActionCfg(
        asset_name="robot",
        #joint_names=["revolute_lift", "revolute_tilt", "revolute_scoop"],
        joint_names=[
            "revolute_cabin","revolute_lift","revolute_tilt",
            "revolute_scoop","revolute_gripper",
        ],
        body_name=EE_BODY,
        controller=DifferentialIKControllerCfg(
            command_type="position",
            use_relative_mode=True,
            ik_method="dls",
            ik_params={"lambda_val": 0.08},
        ),
        scale=0.01,
        body_offset=DifferentialInverseKinematicsActionCfg.OffsetCfg(pos=IK_BODY_OFFSET),
    )

    gripper_action = mdp.BinaryJointPositionActionCfg(
        asset_name="robot",
        joint_names=["revolute_claw_1", "revolute_claw_2"],
        open_command_expr={"revolute_claw_1": -0.872, "revolute_claw_2": -0.872},
        close_command_expr={"revolute_claw_1": +0.506, "revolute_claw_2": +0.506},
    )


@configclass
class EventCfg:
    reset_robot_joints = EventTerm(
        func=mdp.reset_joints_by_scale,
        mode="reset",
        params={"position_range": (0.9, 1.1), "velocity_range": (0.0, 0.0)},
    )

    # ✅ FSM：用 TIP_OFFSET_LOCAL 做 close 判定 + lock
    auto_grasp_log = EventTerm(
        func=mdp.auto_grasp_log_fsm,
        mode="interval",
        interval_range_s=(0.0, 0.0),
        params={
            "robot_asset_cfg": SceneEntityCfg("robot", body_names=[EE_BODY]),
            "log_asset_cfg": SceneEntityCfg("log"),
            "close_dist": 0.10,
            "tcp_offset_local": TIP_OFFSET_LOCAL,
            "tool_joint_names": ("revolute_claw_1", "revolute_claw_2"),
            "grasp_hold_steps": 6,
            "lift_steps": 60,
            "lift_height": 0.12,
            "command_name": "ee_pose",
            "debug_print": True,
            "dbg_interval_s": 1.0,
            "close_z_above": 0.025,
            "close_z_below": 0.030,
            #"close_z_above": 0.015,
            #"close_z_below": 0.030,
            "open_pos": {"revolute_claw_1": -0.872, "revolute_claw_2": -0.872},
            "close_pos": {"revolute_claw_1": +0.506, "revolute_claw_2": +0.506},
        },
    )

    # ✅ 每步同步 command 到 log 顶面：descend 用 tip 判定
    sync_cmd_to_log = EventTerm(
        func=mdp.sync_ee_pose_to_log_upright_yaw_two_stage,
        mode="interval",
        interval_range_s=(0.05, 0.05),
        params={
            "command_name": "ee_pose",
            "robot_asset_cfg": SceneEntityCfg("robot", body_names=[EE_BODY]),
            "log_asset_cfg": SceneEntityCfg("log"),
            "approach_height": 0.10,
            "descend_xy": 0.06,
            "final_z_offset": 0.0385,
            "yaw_offset": 0.0,
            "tcp_offset_local": TIP_OFFSET_LOCAL,
            "log_half_height": LOG_HALF_HEIGHT,
            "upright_base_quat_wxyz": UPRIGHT_QUAT_WXYZ,
            "max_pos_step": 0.01,
            "blend": 0.2,
            "lift_z": 0.18,
        },
    )

    reset_sync_state = EventTerm(func=mdp.reset_sync_ee_pose_state, mode="reset", params={})

    reset_log_near_robot = EventTerm(
        func=mdp.reset_log_near_robot,
        mode="reset",
        params={
            "robot_asset_cfg": SceneEntityCfg("robot"),
            "log_asset_cfg": SceneEntityCfg("log"),
            "offset_b": (0.6, 0.0, -0.09),
        },
    )


@configclass
class CommandsCfg:
    ee_pose = mdp.UniformPoseCommandCfg(
        asset_name="robot",
        body_name=EE_BODY,
        resampling_time_range=(9999.0, 9999.0),
        debug_vis=True,
        ranges=mdp.UniformPoseCommandCfg.Ranges(
            pos_x=(0.6, 0.6),
            pos_y=(0.0, 0.0),
            pos_z=(-0.09, -0.09),
            roll=(0.0, 0.0),
            pitch=(0.0, 0.0),
            yaw=(0.0, 0.0),
        ),
    )


@configclass
class TerminationsCfg:
    time_out = DoneTerm(func=mdp.time_out, time_out=True)

    root_oob = DoneTerm(
        func=mdp.root_position_out_of_bounds,
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "bounds": {"x": (-3.0, 3.0), "y": (-3.0, 3.0), "z": (-1.0, 3.0)},
        },
    )

    ee_speed_oob = DoneTerm(
        func=mdp.ee_speed_above_limit,
        params={"asset_cfg": SceneEntityCfg("robot"), "ee_body_name": EE_BODY, "limit_lin": 0.8, "limit_ang": 6.0},
    )

    any_link_speed_oob = DoneTerm(
        func=mdp.any_body_speed_oob,
        params={"asset_cfg": SceneEntityCfg("robot"), "limit_lin": 0.8, "limit_ang": 6.0},
    )

    any_link_oob = DoneTerm(
        func=mdp.any_body_pos_out_of_bounds,
        params={"asset_cfg": SceneEntityCfg("robot"), "bound": 2.5},
    )

    nan_inf_guard = DoneTerm(func=mdp.has_nan_or_inf, params={"asset_cfg": SceneEntityCfg("robot")})


@configclass
class RewardsCfg:
    end_effector_position_tracking = RewTerm(
        func=mdp_isaac.position_command_error,
        weight=-1.0,
        params={"asset_cfg": SceneEntityCfg("robot", body_names=[EE_BODY]), "command_name": "ee_pose"},
    )

    end_effector_position_tracking_fine_grained = RewTerm(
        func=mdp_isaac.position_command_error_tanh,
        weight=2.0,
        params={"asset_cfg": SceneEntityCfg("robot", body_names=[EE_BODY]), "std": 0.10, "command_name": "ee_pose"},
    )

    action_rate = RewTerm(func=mdp.safe_action_rate_l2, weight=-0.001)

    log_lift_reward = RewTerm(
        func=mdp.log_height_reward,
        weight=1.0,
        params={"log_asset_cfg": SceneEntityCfg("log"), "target_z": 0.15},
    )


@configclass
class MasiIkReachLogEnvCfg(ManagerBasedRLEnvCfg):
    scene: MasiLogSceneCfg = MasiLogSceneCfg(num_envs=1024, env_spacing=2.5)
    observations: ObservationsCfg = ObservationsCfg()
    actions: ActionsCfg = ActionsCfg()
    rewards: RewardsCfg = RewardsCfg()
    terminations: TerminationsCfg = TerminationsCfg()
    events: EventCfg = EventCfg()
    commands: CommandsCfg = CommandsCfg()

    def __post_init__(self):
        super().__post_init__()
        self.scene.robot = MASI_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot")
        self.scene.robot.init_state.pos = (0.0, 0.0, 0.12)
        self.scene.robot.init_state.rot = (1.0, 0.0, 0.0, 0.0)

        self.sim.dt = 1.0 / 60.0
        self.decimation = 2
        self.episode_length_s = 12.0
        self.sim.render_interval = self.decimation


@configclass
class MasiIkReachLogEnvCfg_PLAY(MasiIkReachLogEnvCfg):
    def __post_init__(self):
        super().__post_init__()
        self.scene.num_envs = 32
        self.scene.env_spacing = 2.5
        self.observations.policy.enable_corruption = False
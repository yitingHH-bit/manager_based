from __future__ import annotations

import torch

from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.utils.math import quat_mul, quat_from_euler_xyz, quat_apply


@torch.no_grad()
def reset_sync_ee_pose_state(env: ManagerBasedRLEnv, env_ids: torch.Tensor):
    """Reset sync state buffers (safe to call on reset)."""
    device = env.device
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    if hasattr(env, "_sync_stage"):
        env._sync_stage[env_ids] = 0
    if hasattr(env, "_sync_prev_pos_b"):
        env._sync_prev_pos_b[env_ids] = 0.0
    if hasattr(env, "_sync_prev_yaw_b"):
        env._sync_prev_yaw_b[env_ids] = 0.0


@torch.no_grad()
def sync_ee_pose_to_log_upright_yaw_two_stage(
    env: ManagerBasedRLEnv,
    env_ids: torch.Tensor,
    command_name: str,
    robot_asset_cfg,
    log_asset_cfg,
    # hover / descend logic
    approach_height: float = 0.10,
    descend_xy: float = 0.06,
    final_z_offset: float = 0.0,       # 给“EE body”用的 offset（不是 tip）
    # yaw
    yaw_offset: float = 0.0,
    upright_base_quat_wxyz=(1.0, 0.0, 0.0, 0.0),
    # tip offset (for distance gating + debug)
    tcp_offset_local=(0.0, 0.0, 0.0),
    # log geometry
    log_half_height: float = 0.02,
    # motion smoothing / safety
    snap_dist: float = 0.20,
    max_pos_step: float = 0.03,
    blend: float = 0.2,
    # lift when phase==2 (FSM)
    lift_z: float = 0.18,
):
    """
    每步把 command(ee_pose) 同步到 log 顶面：
    - 先 hover 在上方 approach_height
    - XY 进入 descend_xy 后再垂直下落
    - phase>=1 时锁 XY；phase==2 时锁 Z 并抬升 lift_z
    关键：descend 判定用 tip（ee_body + tcp_offset_local），避免“中心到了但 tip 还没到”。
    """
    device = env.device

    # ---- env_ids ----
    if isinstance(env_ids, slice):
        env_ids = torch.arange(env.num_envs, device=device, dtype=torch.long)[env_ids]
    else:
        env_ids = env_ids.to(device=device, dtype=torch.long)
    if env_ids.numel() == 0:
        return

    robot = env.scene[robot_asset_cfg.name]
    log = env.scene[log_asset_cfg.name]

    # ---- resolve ee body id ----
    ee_body_name = (
        robot_asset_cfg.body_names[0]
        if (hasattr(robot_asset_cfg, "body_names") and len(robot_asset_cfg.body_names) > 0)
        else "ee"
    )
    if (not hasattr(env, "_ee_body_cache")) or (env._ee_body_cache.get(ee_body_name) is None):
        if not hasattr(env, "_ee_body_cache"):
            env._ee_body_cache = {}
        env._ee_body_cache[ee_body_name] = robot.find_bodies(ee_body_name)[0][0]
    ee_body_id = env._ee_body_cache[ee_body_name]

    # ---- current cmd (base-translation frame) ----
    cmd = env.command_manager.get_command(command_name)
    cur_pos_b = cmd[env_ids, 0:3]

    # ---- base pose (world) ----
    base_pos_w = robot.data.root_state_w[env_ids, 0:3]

    # ---- log top (world -> base-translation) ----
    log_pos_w = log.data.root_pos_w[env_ids, :3]
    log_top_w = log_pos_w.clone()
    log_top_w[:, 2] += float(log_half_height)
    des_pos_b = (log_top_w - base_pos_w)
    des_pos_b[:, 2] += float(final_z_offset)

    # ---- tip pos (for gating) ----
    ee_pos_w = robot.data.body_state_w[env_ids, ee_body_id, 0:3]
    ee_quat_w = robot.data.body_state_w[env_ids, ee_body_id, 3:7]
    tip_off = torch.as_tensor(tcp_offset_local, device=device, dtype=torch.float32).view(1, 3)
    tip_w = ee_pos_w + quat_apply(ee_quat_w, tip_off.expand(env_ids.numel(), 3))
    tip_b = tip_w - base_pos_w

    # ---- hover vs descend (use tip distance to target XY) ----
    delta_xy = des_pos_b[:, 0:2] - tip_b[:, 0:2]
    dist_xy = torch.linalg.norm(delta_xy, dim=1)

    hover_pos_b = des_pos_b.clone()
    hover_pos_b[:, 2] += float(approach_height)

    target_pos_b = torch.where(
        (dist_xy > float(descend_xy)).unsqueeze(1),
        hover_pos_b,
        des_pos_b,
    )

    # ---- phase override from FSM locks ----
    if hasattr(env, "_grasp_phase"):
        phase = env._grasp_phase[env_ids]

        # phase>=1: lock XY (BASE frame)
        if hasattr(env, "_lock_xy"):
            mask_hold = phase >= 1
            if mask_hold.any():
                target_pos_b[mask_hold, 0:2] = env._lock_xy[env_ids[mask_hold]]

        # phase==2: lock z0 + lift
        if hasattr(env, "_lock_z0"):
            mask_lift = phase == 2
            if mask_lift.any():
                target_pos_b[mask_lift, 2] = env._lock_z0[env_ids[mask_lift]] + float(lift_z)

    # ---- snap + limited step ----
    delta = target_pos_b - cur_pos_b
    dist = torch.linalg.norm(delta, dim=1)

    far = dist > float(snap_dist)
    if far.any():
        cur_pos_b[far] = target_pos_b[far]

    near = ~far
    if near.any():
        step = delta[near]
        step_len = torch.linalg.norm(step, dim=1, keepdim=True).clamp(min=1e-8)
        step = step * torch.clamp(float(max_pos_step) / step_len, max=1.0)
        cur_pos_b[near] += step

    new_pos_b = cur_pos_b

    # ---- orientation (upright + yaw_offset) ----
    upright_quat = (
        torch.tensor(upright_base_quat_wxyz, device=device, dtype=torch.float32)
        .view(1, 4)
        .expand(env_ids.numel(), 4)
    )
    roll = torch.zeros((env_ids.numel(), 1), device=device)
    pitch = torch.zeros((env_ids.numel(), 1), device=device)
    yaw = torch.full((env_ids.numel(), 1), float(yaw_offset), device=device)
    yaw_quat = quat_from_euler_xyz(roll, pitch, yaw).view(env_ids.numel(), 4)
    new_quat_b = quat_mul(upright_quat, yaw_quat)

    # ---- blend ----
    prev_pos = cmd[env_ids, 0:3]
    prev_quat = cmd[env_ids, 3:7]

    blended_pos = prev_pos * (1.0 - float(blend)) + new_pos_b * float(blend)

    dot = torch.sum(prev_quat * new_quat_b, dim=1, keepdim=True)
    dot = torch.clamp(dot, -1.0, 1.0)
    theta = torch.acos(dot) * float(blend)
    rel = new_quat_b - prev_quat * dot
    rel = torch.nn.functional.normalize(rel, dim=1)
    blended_quat = prev_quat * torch.cos(theta) + rel * torch.sin(theta)
    blended_quat = torch.nn.functional.normalize(blended_quat, dim=1)

    # ---- write back ----
    cmd[env_ids, 0:3] = blended_pos
    cmd[env_ids, 3:7] = blended_quat
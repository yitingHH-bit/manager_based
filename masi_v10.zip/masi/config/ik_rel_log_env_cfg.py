from dataclasses import MISSING
import math

import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg, AssetBaseCfg, RigidObjectCfg
from isaaclab.controllers.differential_ik_cfg import DifferentialIKControllerCfg
from isaaclab.envs import ManagerBasedRLEnvCfg
from isaaclab.envs.mdp.actions.actions_cfg import DifferentialInverseKinematicsActionCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import RewardTermCfg as RewTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.utils import configclass
from isaaclab.utils.noise import AdditiveUniformNoiseCfg as Unoise

import isaaclab_tasks.manager_based.manipulation.reach.mdp as mdp_isaac
from isaaclab_assets.robots.masiV0 import MASI_CFG
from .. import mdp


# -----------------------------------------------------------------------------
# scenes：MASI + log  
# -----------------------------------------------------------------------------
@configclass
class MasiLogSceneCfg(InteractiveSceneCfg):
    """Scene with MASI and a simple log object to reach."""

    robot: ArticulationCfg = MISSING

    log: RigidObjectCfg = RigidObjectCfg(
        prim_path="{ENV_REGEX_NS}/Log",
        spawn=sim_utils.CuboidCfg(
            #size=(0.04, 0.20, 0.04),
            size=(0.04, 0.05, 0.04),
            rigid_props=sim_utils.RigidBodyPropertiesCfg(
                max_linear_velocity=10.0,
                max_angular_velocity=30.0,
            ),
            collision_props=sim_utils.CollisionPropertiesCfg(),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.100),
            physics_material=sim_utils.RigidBodyMaterialCfg(
            static_friction=1.5,
            dynamic_friction=1.5,
            restitution=0.0,
        ),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.1, 0.0)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(
            pos=(0.6, 0.0, 0.03),
            rot=(1.0, 0.0, 0.0, 0.0),
        ),
    )

    plane = AssetBaseCfg(
        prim_path="/World/GroundPlane",
        init_state=AssetBaseCfg.InitialStateCfg(),
        spawn=sim_utils.GroundPlaneCfg(),
    )

    light = AssetBaseCfg(
        prim_path="/World/Light",
        spawn=sim_utils.DomeLightCfg(intensity=3000.0, color=(0.75, 0.75, 0.75)),
    )


# -----------------------------------------------------------------------------
# Observations
# -----------------------------------------------------------------------------
@configclass
class ObservationsCfg:

    @configclass
    class PolicyCfg(ObsGroup):
        joint_pos = ObsTerm(func=mdp.joint_pos_rel,
                            noise=Unoise(n_min=-0.01, n_max=0.01))
        joint_vel = ObsTerm(func=mdp.joint_vel_rel,
                            noise=Unoise(n_min=-0.01, n_max=0.01))

        # 目标末端位姿命令（来自 CommandsCfg.ee_pose）
        pose_command_ee = ObsTerm(
            func=mdp.generated_commands,
            params={"command_name": "ee_pose"},
        )

        # log 相对 base 的方向特征
        log_dir = ObsTerm(func=mdp.log_dir_in_base)

        # 上一步动作
        actions = ObsTerm(func=mdp.last_action)

        def __post_init__(self):
            self.enable_corruption = False
            self.concatenate_terms = True

    policy: PolicyCfg = PolicyCfg()


# -----------------------------------------------------------------------------
# Actions：arm 由 RL 控制，gripper 由规则覆盖
# -----------------------------------------------------------------------------
@configclass
class ActionsCfg:
    arm_action = DifferentialInverseKinematicsActionCfg(
        asset_name="robot",
        joint_names=[
            "revolute_cabin",
            "revolute_lift",
            "revolute_tilt",
            "revolute_scoop",
            #"revolute_gripper",
        ],
        body_name="ee",
        controller=DifferentialIKControllerCfg(
            #command_type="pose", #v4
            #command_type="position",  #v3
            command_type="position",  # v9 uncomment
            use_relative_mode=True,
            
            ik_method="dls",
            ik_params={"lambda_val": 0.08},
        ),
        scale=0.01,  # 这个先保持 0.01，力度已经比之前大很多
        body_offset=DifferentialInverseKinematicsActionCfg.OffsetCfg(
            # 关键改动：把“虚拟末端”从 ee 向下挪一段到铲斗前端
            # 数值你可以微调，先试 -0.25，如果目标点还在铲斗中间就再缩小一点
            pos=[0.0, 0.0, -0.19],  # v9   pos=[0.0, 0.0, -0.19],
            #rot=[0.7071068, 0.0, 0.7071068, 0.0],   # v9   绕 Y 轴 +90°  
        ),
    )

    gripper_action = mdp.BinaryJointPositionActionCfg(
        asset_name="robot",
        joint_names=["revolute_claw_1", "revolute_claw_2"],
        open_command_expr={
            "revolute_claw_1": +0.6,
            "revolute_claw_2": -0.6,
        },
        close_command_expr={
            "revolute_claw_1": 0.0,
            "revolute_claw_2": 0.0,
        },
    )


# -----------------------------------------------------------------------------
# Events：重置 + 自动抓取 FSM
# -----------------------------------------------------------------------------
@configclass
class EventCfg:
    """Configuration for events."""

    reset_robot_joints = EventTerm(
        func=mdp.reset_joints_by_scale,
        mode="reset",
        params={
            "position_range": (0.9, 1.1), #(0.5, 1.5),
            #"position_range": (1.0, 1.0),  #v3  
            "velocity_range": (0.0, 0.0),
        },
    )

    # 规则控制爪子的有限状态机：
    #   0: OPEN   - 强制张开
    #   1: CLOSING- 末端接近 log 后自动闭合
    #   2: GRASPED- 抓住并抬起后保持闭合
    auto_grasp_log = EventTerm(
        func=mdp.auto_grasp_log_fsm,
        mode="interval", 
        interval_range_s=(0.0, 0.0),  # 每个 step 都调用
        params={

        "robot_asset_cfg": SceneEntityCfg("robot", body_names=["ee"]),
        "log_asset_cfg": SceneEntityCfg("log"),

        "close_dist": 0.02,         # 更近才闭合（2cm）
        "keep_open_xy": 0.10,       # XY 还没对齐到 10cm 内，就强制张开
        "keep_open_z_above": 0.02,  # EE 比 log 中心高 >2cm，也强制张开（避免路上乱夹）

        "lift_height": 0.15,
        "open_action": 1.0,
        "close_action": -1.0,
        },
    )

#
#
#     sync_command_with_log = EventTerm(
#     func=mdp.sync_ee_pose_to_log_center,
#     mode="interval",
#     interval_range_s=(0.0, 0.0),  # 每步更新
#     params={
#         "command_name": "ee_pose",
#         "robot_asset_cfg": SceneEntityCfg("robot"),
#         "log_asset_cfg": SceneEntityCfg("log"),
#         "z_offset": 0.0,          # 目标=log中心；如果想抓上表面可设 0.02
#     },
# )
    
# v4 
#     sync_command_with_log = EventTerm(
#     func=mdp.sync_ee_pose_to_log_center_upright,
#     mode="interval",
#     interval_range_s=(0.0, 0.0),
#     params={
#         "command_name": "ee_pose",
#         "robot_asset_cfg": SceneEntityCfg("robot"),
#         "log_asset_cfg": SceneEntityCfg("log"),
#         "z_offset": 0.0,
#         "world_upright_quat_wxyz": (0.0, 1.0, 0.0, 0.0),
#     },
# )
    #  目标点每步跟随 log：先悬停再垂直下落 + 期望姿态（竖直 + yaw 对齐）
    sync_cmd_to_log = EventTerm(
        func=mdp.sync_ee_pose_to_log_upright_yaw_two_stage,
        mode="interval",
        interval_range_s=(0.05, 0.05),
        params={
            "command_name": "ee_pose",
            "robot_asset_cfg": SceneEntityCfg("robot", body_names=["ee"]),
            "log_asset_cfg": SceneEntityCfg("log"),
            "approach_height": 0.10,
            "descend_xy": 0.06,
            "final_z_offset": 0.03,  # v9 抓 log 表面稍微高一点
            "yaw_offset": 0.0,
            #"backoff_dist": 0.04,   #  v9  退 4cm（先从 0.02~0.05 试）
            "tcp_offset_local": (0.0, 0.0, 0.0),# v9 抓 log 表面稍微高一点
            "upright_base_quat_wxyz": (1.0, 0.0, 0.0, 0.0),
            "max_pos_step": 0.01,
        },
    )

    reset_sync_state = EventTerm(
    func=mdp.reset_sync_ee_pose_state,
    mode="reset",
    params={},
)

# 每次 reset：把 log 放在机器人前方固定距离（root frame 下）
    reset_log_near_robot = EventTerm(
    func=mdp.reset_log_near_robot,
    mode="reset",
    params={
        "robot_asset_cfg": SceneEntityCfg("robot"),
        "log_asset_cfg": SceneEntityCfg("log"),
        "offset_b": (0.6, 0.0, -0.09),  # ✅ 机器人root坐标系下：前方0.6m，z对齐地面附近
    },
)

# 每步检查：如果 log 被推太远，就拉回去（可选）
    pull_back_log_if_far = EventTerm(
    func=mdp.pull_back_log_if_far,
    mode="interval",
    interval_range_s=(0.0, 0.0),
    params={
        "robot_asset_cfg": SceneEntityCfg("robot"),
        "log_asset_cfg": SceneEntityCfg("log"),
        "offset_b": (0.6, 0.0, -0.09),
        "max_dist": 0.9,  # ✅ 超过0.9m就拉回
    },
)
    # keep_gripper_vertical = EventTerm(
    # func=mdp.keep_gripper_vertical,
    # mode="interval",
    # interval_range_s=(0.0, 0.0),  # 每步
    # params={
    #     "asset_cfg": SceneEntityCfg("robot"),
    #     "pitch_chain_joints": ["revolute_lift", "revolute_tilt", "revolute_scoop"],
    #     "wrist_joint": "revolute_gripper",

    #     # 目标：爪子竖直向下（先用 -90°）
    #     #"pitch_des": -0.57079632679, # v9 commented
    #     "pitch_des": -1.57079632679,   # -90° v9  uncommented
    #     # 机械零偏（如果你发现永远差一个固定角度，就调这个）
    #     "pitch0": 0.0,
    # },
#)

    #每次 reset 时，把 log 挪到当前 ee_pose 命令的正下方
    # sync_log_with_command = EventTerm(
    #     func=mdp.move_log_under_command,
    #     mode="reset",
    #     params={
    #         "command_name": "ee_pose",
    #         "robot_asset_cfg": SceneEntityCfg("robot"),
    #         "log_asset_cfg": SceneEntityCfg("log"),
    #         "log_height": 0.04,      # 上面 CuboidCfg 里 size 的 z
    #     },
    # )
# -----------------------------------------------------------------------------
# Commands：末端目标 ee_pose 绑在木头上方
# -----------------------------------------------------------------------------
@configclass
class CommandsCfg:
    """Command terms for the MDP."""

    ee_pose = mdp.UniformPoseCommandCfg(
        asset_name="robot",
        body_name="ee",
        resampling_time_range=(9999.0, 9999.0),
        debug_vis=True,
        ranges=mdp.UniformPoseCommandCfg.Ranges(
    pos_x=(0.6, 0.6),
    pos_y=(0.0, 0.0),
    pos_z=(-0.09, -0.09),
    roll=(0.0, 0.0),
    pitch=(0.0, 0.0),
    yaw=(0.0, 0.0),
)
    )

# -----------------------------------------------------------------------------
# Terminations：与你之前的一样
# -----------------------------------------------------------------------------
@configclass
class TerminationsCfg:
    time_out = DoneTerm(func=mdp.time_out, time_out=True)

    root_oob = DoneTerm(
        func=mdp.root_position_out_of_bounds,
        params={"asset_cfg": SceneEntityCfg("robot"),
                "bounds": {"x": (-3.0, 3.0), "y": (-3.0, 3.0), "z": (-1.0, 3.0)}}
    )

    ee_speed_oob = DoneTerm(
        func=mdp.ee_speed_above_limit,
        params={"asset_cfg": SceneEntityCfg("robot"),
                "ee_body_name": "ee",
                "limit_lin": 0.8, "limit_ang": 6.0}
    )

    any_link_speed_oob = DoneTerm(
        func=mdp.any_body_speed_oob,
        params={"asset_cfg": SceneEntityCfg("robot"),
                "limit_lin": 0.8, "limit_ang": 6.0}
    )

    any_link_oob = DoneTerm(
        func=mdp.any_body_pos_out_of_bounds,
        params={"asset_cfg": SceneEntityCfg("robot"), "bound": 2.5},
    )

    nan_inf_guard = DoneTerm(
        func=mdp.has_nan_or_inf,
        params={"asset_cfg": SceneEntityCfg("robot")},
    )


# -----------------------------------------------------------------------------
# Rewards：EE tracking + 轻量 log shaping + 动作惩罚
# -----------------------------------------------------------------------------
@configclass
class RewardsCfg:
    """Reward terms for the MDP."""

    # ---- 主任务：末端 tracking ----
    end_effector_position_tracking = RewTerm(
        func=mdp_isaac.position_command_error,
        weight=-1.0,  # 惩罚 error，负号
        params={
            "asset_cfg": SceneEntityCfg("robot", body_names=["ee"]),
            "command_name": "ee_pose",
        },
    )
    
    end_effector_position_tracking_fine_grained = RewTerm(
        func=mdp_isaac.position_command_error_tanh,
        weight=2.0,    # 适当放大，让靠近目标时有更大正奖励
        params={
            "asset_cfg": SceneEntityCfg("robot", body_names=["ee"]),
            "std": 0.10,
            "command_name": "ee_pose",
        },
    )
    
    # ---- 先把这些 log 相关的 shaping 暂时关掉 / 降权 ----
    # 训练稳定后再慢慢加回（或改成成功奖励）
    # reaching_log = RewTerm(func=mdp.ee_to_log_distance, weight=0.0)
    # cabin_yaw_align = RewTerm(func=mdp.cabin_yaw_aligns_target, weight=0.0, params={"eps": 1e-3})

    # ---- 动作惩罚 ----
    action_rate = RewTerm(
        func=mdp.safe_action_rate_l2,
        weight=-0.001,
    )

    log_lift_reward = RewTerm(
    func=mdp.log_height_reward,
    weight=1.0,
    params={"log_asset_cfg": SceneEntityCfg("log"), "target_z": 0.15},
)
 # ✅ 新增：姿态 tracking（这一步是“爪子不再歪”的关键）  v9 commented
    # end_effector_orientation_tracking = RewTerm(
    #     func=mdp_isaac.orientation_command_error,
    #     weight=-0.5,
    #     params={"asset_cfg": SceneEntityCfg("robot", body_names=["ee"]), "command_name": "ee_pose"},
    # )
# -----------------------------------------------------------------------------
# Env
# -----------------------------------------------------------------------------
@configclass
class MasiIkReachLogEnvCfg(ManagerBasedRLEnvCfg):
    scene: MasiLogSceneCfg = MasiLogSceneCfg(num_envs=1024, env_spacing=2.5)
    observations: ObservationsCfg = ObservationsCfg()
    actions: ActionsCfg = ActionsCfg()
    rewards: RewardsCfg = RewardsCfg()
    terminations: TerminationsCfg = TerminationsCfg()
    events: EventCfg = EventCfg()
    commands: CommandsCfg = CommandsCfg()

    def __post_init__(self):
        super().__post_init__()
        self.scene.robot = MASI_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot")
        self.scene.robot.init_state.pos = (0.0, 0.0, 0.12)
        self.scene.robot.init_state.rot = (1.0, 0.0, 0.0, 0.0)

        self.sim.dt = 1.0 / 60.0
        self.decimation = 2
        self.episode_length_s = 12.0
        self.sim.render_interval = self.decimation


@configclass
class MasiIkReachLogEnvCfg_PLAY(MasiIkReachLogEnvCfg):
    def __post_init__(self):
        super().__post_init__()
        self.scene.num_envs = 32
        self.scene.env_spacing = 2.5
        self.observations.policy.enable_corruption = False
